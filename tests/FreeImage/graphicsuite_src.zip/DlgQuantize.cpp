#include "stdafx.h"
#include "graphicsuite.h"
#include "DlgQuantize.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

//////////////////////////////////////////////////////////////////////
//
// CDlgQuantize
//
//////////////////////////////////////////////////////////////////////

BEGIN_MESSAGE_MAP(CDlgQuantize, CDialog)
	//{{AFX_MSG_MAP(CDlgQuantize)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

CDlgQuantize::CDlgQuantize(CWnd* pParent /*=NULL*/)
	: CDialog(CDlgQuantize::IDD, pParent)
{
	//{{AFX_DATA_INIT(CDlgQuantize)
	m_type = 0;
	//}}AFX_DATA_INIT
}


void CDlgQuantize::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CDlgQuantize)
	DDX_Radio(pDX, IDC_RADIO_CLASSIC, m_type);
	//}}AFX_DATA_MAP
}
