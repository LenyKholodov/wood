#include "stdafx.h"
#include "graphicsuite.h"
#include "DlgTile.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

//////////////////////////////////////////////////////////////////////
//
// CDlgTile
//
//////////////////////////////////////////////////////////////////////


BEGIN_MESSAGE_MAP(CDlgTile, CDialog)
	//{{AFX_MSG_MAP(CDlgTile)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

CDlgTile::CDlgTile(CWnd* pParent /*=NULL*/)
	: CDialog(CDlgTile::IDD, pParent)
{
	//{{AFX_DATA_INIT(CDlgTile)
	m_dHor = 1;
	m_dVert = 1;
	//}}AFX_DATA_INIT
}


void CDlgTile::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CDlgTile)
	DDX_Text(pDX, IDC_EDIT_HOR, m_dHor);
	DDX_Text(pDX, IDC_EDIT_VERT, m_dVert);
	//}}AFX_DATA_MAP
}

