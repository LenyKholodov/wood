#include "stdafx.h"
#include "graphicsuite.h"
#include "DlgZoom.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

//////////////////////////////////////////////////////////////////////
//
// CDlgZoom
//
//////////////////////////////////////////////////////////////////////

BEGIN_MESSAGE_MAP(CDlgZoom, CDialog)
	//{{AFX_MSG_MAP(CDlgZoom)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

CDlgZoom::CDlgZoom(CWnd* pParent, double zoom, double factor)
	: CDialog(CDlgZoom::IDD, pParent)
{
	//{{AFX_DATA_INIT(CDlgZoom)
	m_editFactor = factor;
	m_editValue = zoom;
	//}}AFX_DATA_INIT
}

void CDlgZoom::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CDlgZoom)
	DDX_Text(pDX, IDC_EDIT_FACTOR, m_editFactor);
	DDX_Text(pDX, IDC_EDIT_VALUE, m_editValue);
	//}}AFX_DATA_MAP
}
