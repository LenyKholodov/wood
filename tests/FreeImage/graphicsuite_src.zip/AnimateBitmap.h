#if !defined(AFX_ANIMATEBITMAP_H__7FBC931D_B8B5_11D3_97F7_00201828908C__INCLUDED_)
#define AFX_ANIMATEBITMAP_H__7FBC931D_B8B5_11D3_97F7_00201828908C__INCLUDED_

#pragma once

#include "DIBSectionLite.h"

/////////////////////////////////////////////////////////////////////////////
//
// CAnimateBmpCtrl 
//
/////////////////////////////////////////////////////////////////////////////

/*
TODO
PauseAnimation(DWORD in Millisec)
UseTiledFrames(BOOL bUse, COLORREF=RGB(0,0,0))     dann werden nicht komplette Kacheln auch verwendet und mit der Farbe aufgef�llt)
CAnimateBmpCtrl::InitializeLoaded: Ausrichtung
*/

class CAnimateBmpCtrl : public CStatic
{
public:
	CAnimateBmpCtrl();
	virtual ~CAnimateBmpCtrl();

	//
	// Ein Frame ist ein "einzelnes" Bild innerhalb des grossen
	//

	// Laden der Bitmap
	BOOL	Load(UINT id, int frameSizeX, int frameSizeY, BOOL bSkipTiledImages = TRUE, int arrangement=0);
	BOOL	Load(const char *szFile, int frameSizeX, int frameSizeY, BOOL bSkipTiledImages = TRUE, int arrangement=0);

	// Frames
	BOOL	SetDefaultFrame(int nr);	// Setzt eine neue DefaultNr, def = 0
	BOOL	ShowFrame(int nr);			// Stoppt animation, zeigt statisch Frame
										// -1 dann default
	int		GetCurrentFrame(void);
	int		GetDefaultFrame(void);

	void	SetFrameArrangementFirstRightThenDown(void);	//  zuerst nach rechts oder nach unten
	void	SetFrameArrangementFirstDownThenRight(void);
	int		GetAmountFrames(void);

	void	UseBkColor(COLORREF color);
	void	UseDefaultBkColor(void);
	
	// Animation

	// vollst�ndige Runden
			// -1, dann dauerhaft
	BOOL	Animate(int amountFullCycles, DWORD deltaInMS, BOOL bContinueWithFirst = TRUE);
	// einzelne Frames
	BOOL	AnimateFrames(int amountFrames, DWORD deltaInMS);

	BOOL	IsAnimating(void);
	void	Stop(BOOL bLeaveFrameAsIs);	// -> sonst Default

	//{{AFX_VIRTUAL(CAnimateBmpCtrl)
	protected:
	virtual void PreSubclassWindow();
	//}}AFX_VIRTUAL

protected:
	CDIBSectionLite		m_DIBSection;

	int					m_frameSizeX,
						m_frameSizeY;
	int					m_frameNrMax,
						m_frameNrActual,
						m_frameNrDefault;
	BOOL				m_bSkipTiledImages,
						m_bAnimating,
						m_ArrangementRightFirst,
						m_bUseDefaultBkColor,
						m_bContinueWithFirst,
						m_bGoingNext;
	int					m_amountFramesRightInBmp,
						m_amountFramesBottomInBmp;
	int					m_timerTicksLeft;
	UINT				m_TimerId;
	COLORREF			m_bkColor;

protected:
	virtual void		Initialize(BOOL bIsSubclassed);
	void				InitializeLoaded(int frameSizeX, int frameSizeY, BOOL bSkipTiledImages, int arrangement);
	void				CalculateFrames(void);

	BOOL				GetFramePosition(int frameNr, int &posX, int &posY);
	void				StopAnimation(void);

	//{{AFX_MSG(CAnimateBmpCtrl)
	afx_msg void OnPaint();
	afx_msg BOOL OnEraseBkgnd(CDC* pDC);
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
	afx_msg void OnTimer(UINT nIDEvent);
	//}}AFX_MSG

	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////
//
// CAnimateBmpThreadCtrl
//
/////////////////////////////////////////////////////////////////////////////

#define WM_ANIMATE_BMP_START				WM_APP + 111
#define WM_ANIMATE_BMP_SET_DEFAULT_FRAME	WM_ANIMATE_BMP_START + 0
#define WM_ANIMATE_BMP_SET_CONTINUE_FIRST	WM_ANIMATE_BMP_START + 1
#define WM_ANIMATE_BMP_SHOW_FRAME			WM_ANIMATE_BMP_START + 2
#define WM_ANIMATE_BMP_ANIMATE				WM_ANIMATE_BMP_START + 3
#define WM_ANIMATE_BMP_ANIMATE_FRAMES		WM_ANIMATE_BMP_START + 4
#define WM_ANIMATE_BMP_STOP					WM_ANIMATE_BMP_START + 5
#define WM_ANIMATE_BMP_EXIT					WM_ANIMATE_BMP_START + 6

UINT	AnimateThreadProc(LPVOID pParam);

class CAnimateBmpThreadCtrl : public CObject
{
public:
	CAnimateBmpThreadCtrl();
	virtual ~CAnimateBmpThreadCtrl();

	//
	// diese Funktionen werden von extern aufgerufen
	//
	// create
	BOOL	Create(CWnd *pParent, CRect &rectCreate, UINT idWnd, UINT idBmp, int frameSizeX, int frameSizeY, BOOL bSkipTiledImages = TRUE, int arrangement=0);
	BOOL	Create(CWnd *pParent, CRect &rectCreate, UINT idWnd, const char *szFile, int frameSizeX, int frameSizeY, BOOL bSkipTiledImages = TRUE, int arrangement=0);
	// frames
	void	SetDefaultFrame(int nr);
	void	ShowFrame(int nr);
	// Animation
	void	Animate(int amountFullCycles, DWORD deltaInMS, BOOL bContinueWithFirst = TRUE);
	void	AnimateFrames(int amountFrames, DWORD deltaInMS);
	void	Stop(BOOL bLeaveFrameAsIs);

public:
	// diese Funktionen werden vom Thread aus aufgerufen
	BOOL	CreateControl(CAnimateBmpCtrl &animateCtrl);

protected:
	// Wnd-Sachen
	CWnd		*m_pParent;
	CRect		m_rect;
	UINT		m_idWnd;
	// Animate-Sachen
	UINT		m_idBmp;
	CString		m_File;
	int			m_FrameSizeX,
				m_FrameSizeY;
	BOOL		m_bSkipTiledImages;
	int			m_arrangement;

	CWinThread		*m_pThread;
	CAnimateBmpCtrl	*m_pCtrl;
};

//{{AFX_INSERT_LOCATION}}

#endif // AFX_ANIMATEBITMAP_H__7FBC931D_B8B5_11D3_97F7_00201828908C__INCLUDED_
