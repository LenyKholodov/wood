#if !defined(AFX_GRAPHICSUITE_H__7E4994D3_9D63_4FFF_8730_805F1DC9F7C2__INCLUDED_)
#define AFX_GRAPHICSUITE_H__7E4994D3_9D63_4FFF_8730_805F1DC9F7C2__INCLUDED_

#pragma once

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"

#define GET_APP(var)	CGraphicSuiteApp *##var = (CGraphicSuiteApp *) AfxGetApp();

#define WM_USER_GRAPHICSUITE            (WM_APP + 200)       // just a value

#define WM_FILE_OPENED_SINGLE           (WM_USER_GRAPHICSUITE + 2)
		// wParam = ItemId from file
		// lParam = handle (FIBITMAP *) (success) or NULL

#define WM_FILE_OPENED_MULTI            (WM_USER_GRAPHICSUITE + 3)
		// wParam = ItemId from file
		// lParam = handle (FIMULTIBITMAP*) (success) or NULL

#define WM_FREEIMAGE_MSG                (WM_USER_GRAPHICSUITE + 4)
		// wParam = CString *

#define WM_PAGE_OPENED                  (WM_USER_GRAPHICSUITE + 5)
		// wParam = pageNr
		// lParam = handle (FIBITMAP *) (success) or NULL

/////////////////////////////////////////////////////////////////////////
//
// Fehlercodes (Typ HRESULT)
//
/////////////////////////////////////////////////////////////////////////

// 
// Errorcodes �hnlich wie in winerror.h definiert
//
//
//  HRESULTs mit folgendem Aufbau:
//
//   3 3 2 2 2 2 2 2 2 2 2 2 1 1 1 1 1 1 1 1 1 1
//   1 0 9 8 7 6 5 4 3 2 1 0 9 8 7 6 5 4 3 2 1 0 9 8 7 6 5 4 3 2 1 0
//  +-+-+-+-+-+---------------------+-------------------------------+
//  |S|  Msg  |    Facility         |               Code            |
//  +-+-+-+-+-+---------------------+-------------------------------+
//
//  where
//
//      S - Severity - indicates success/fail
//
//          0 - Success
//          1 - Fail (COERROR)
//
//      Msg - message-Type
//										LogDatei   MsgBox  Abbruch
#define ERROR_NULL				0	//		    
#define ERROR_JUST_INFO_LOG		1	//		x
#define ERROR_INFORM			2	//      x          x
#define ERROR_EXIT_ADVICE		3	//      x          x       Vorschlag
#define ERROR_EXIT_FORCE		4	//      x          x       x
//
//      Facility - is the facility code
//
#define JOB_FACILITY_NULL		0
#define JOB_FACILITY_USER		1
#define JOB_FACILITY_STORAGE	2
#define JOB_FACILITY_WINDOWS	4
#define JOB_FACILITY_CLIENT		5
#define JOB_FACILITY_SERVER		6
//
//      Code - is the facility's status code
//
#define JOB_CODE_NOTSPECIFIED		0
#define JOB_CODE_NOTIMPL			1
#define JOB_CODE_BADRESPONSE		2
#define JOB_CODE_NOTHINGTODO		3
#define JOB_CODE_UNEXPECTED			4
#define JOB_CODE_EXTERNALSTOP		5
#define JOB_CODE_DATACORRUPT		6
#define JOB_CODE_SENDPROBLEM		7
#define JOB_CODE_INTERNALSTOP		8
#define JOB_CODE_MULTIPLEPROBLEMS	9
#define JOB_CODE_LOWRESSOURCE		10
#define JOB_CODE_NOTALLOWED		    11

//
// Makros (analog wie in winuser.h)
//

// Abfragen
#define JOB_SUCCEEDED(Status)	((HRESULT)(Status) >= 0)
#define JOB_FAILED(Status)		((HRESULT)(Status)<0)
#define JOB_CODE(hr)			((hr) & 0xFFFF)			// TODO
#define JOB_FACILITY(hr)		(((hr) >> 16) & 0x7FF)
#define JOB_MSGTYPE(hr)			(((hr) >> 27) & 0xF)

// Erzeugen
#define JOB_CODE_OK		0

#define JOB_CREATE_CODE(fail,msgtype,facility,code)	((HRESULT) ( \
			((unsigned long)(fail)					<<31) | \
			((unsigned long)(msgtype)				<<27) | \
			((unsigned long)(facility)				<<16) | \
			((unsigned long)(code))) )

#define JOB_CREATE_CLIENT_ERROR(code)				((HRESULT) ( \
			((unsigned long)(1)						<<31) | \
			((unsigned long)(ERROR_INFORM)			<<27) | \
			((unsigned long)(JOB_FACILITY_CLIENT)	<<16) | \
			((unsigned long)(code))) )

#define JOB_CREATE_CLIENT_CANCEL					((HRESULT) ( \
			((unsigned long)(1)						<<31) | \
			((unsigned long)(ERROR_JUST_INFO_LOG)	<<27) | \
			((unsigned long)(JOB_FACILITY_CLIENT)	<<16) | \
			((unsigned long)(JOB_CODE_INTERNALSTOP))) )

#define JOB_CREATE_CLIENT_JOBKILLER					((HRESULT) ( \
			((unsigned long)(1)						<<31) | \
			((unsigned long)(ERROR_JUST_INFO_LOG)	<<27) | \
			((unsigned long)(JOB_FACILITY_CLIENT)	<<16) | \
			((unsigned long)(JOB_CODE_EXTERNALSTOP))) )

#define JOB_SERVER_ERROR							((HRESULT) ( \
			((unsigned long)(1)						<<31) | \
			((unsigned long)(ERROR_INFORM)			<<27) | \
			((unsigned long)(JOB_FACILITY_SERVER)	<<16) | \
			((unsigned long)(JOB_CODE_BADRESPONSE))) )

#define JOB_SERVER_NOTIMPL							((HRESULT) ( \
			((unsigned long)(1)						<<31) | \
			((unsigned long)(ERROR_INFORM)			<<27) | \
			((unsigned long)(JOB_FACILITY_SERVER)	<<16) | \
			((unsigned long)(JOB_CODE_NOTIMPL))) )

//////////////////////////////////////////////////////////////////////
//
// CJob
//
//////////////////////////////////////////////////////////////////////
class CGraphicSuiteApp;

enum { JOB_PRIORITY_LOW, JOB_PRIORITY_NORMAL, JOB_PRIORITY_HIGH, JOB_PRIORITY_EXTREME };

class CJob : public CCmdTarget
{
	DECLARE_DYNCREATE(CJob)

public:
	CJob(CWnd *pNotifyMe = NULL, int priority = JOB_PRIORITY_NORMAL, BOOL bSkipOld = FALSE);
	virtual ~CJob();

	// zu �berladen 
	virtual HRESULT	DoJob(CString &errorCode);
	virtual BOOL	RunJobScript(void);

	BOOL	IsAllowedToSkipOld(void)	{ return m_bSkipOldAllowed;	}
	UINT	GetPriority(void)			{ return m_dPriority;		}
	CWnd	*GetNotifier(void)			{ return m_pNotifyMe;		}
	BOOL	NotifyCaller(UINT message, WPARAM wParam, LPARAM lParam);
	BOOL	NotifyMainFrame(BOOL bForceNow, UINT message, WPARAM wParam, LPARAM lParam);

	// Progress-Fenster
/*	void	SetProgressText(CString &str);
	void	SetProgressTitle(CString &str);
	void	SetProgressMax(unsigned int max);
	void	ShowProgress(BOOL bShow);
	BOOL	SetProgressPos(unsigned int val);
*/
protected:
	CGraphicSuiteApp	*m_pApp;
	CWnd				*m_pNotifyMe;		// entweder ein Frame oder ein CView (PostMessage)
										// bei NULL wirds an MainFrame  geschickt
	int				m_dPriority;		// mit dieser Priorit�t werden diese abgearbeitet
	BOOL			m_bSkipOldAllowed;	// TRUE: dann werden alte Meldungen weggeworfen

	//{{AFX_VIRTUAL(CJob)
	//}}AFX_VIRTUAL

	//{{AFX_MSG(CJob)
	//}}AFX_MSG

	DECLARE_MESSAGE_MAP()
};

// gleichen Member wie CObList
typedef CTypedPtrList<CPtrList, CJob*> CListJobs;

//////////////////////////////////////////////////////////////////////
//
//  CJobStopCurrent
//
//////////////////////////////////////////////////////////////////////

//
// kommt von:     CRissClientApp::_jobdata::StopRetrievalThreadXX()
//                CRissClientApp::_jobdata::StopCurrentJobXX()
// erzeugt:
// schickt nach:  todo
//
class CJobStopCurrent : public CJob
{
	DECLARE_DYNCREATE(CJobStopCurrent)

public:
	CJobStopCurrent(BOOL bStopThread = FALSE);
	virtual			~CJobStopCurrent();
	
	virtual HRESULT	DoJob(CString &errorCode);

	BOOL	m_bStopThread;
};

//////////////////////////////////////////////////////////////////////
//
//  CJobOpenDocument
//
//////////////////////////////////////////////////////////////////////

//
class CJobOpenDocument : public CJob
{
	DECLARE_DYNCREATE(CJobOpenDocument)

public:
	CJobOpenDocument(CWnd *pNotifyMe = NULL, int priority = JOB_PRIORITY_NORMAL, BOOL bSkipOld = FALSE, 
					CString &filename = CString(), DWORD itemId=0);
	virtual			~CJobOpenDocument();
	
	virtual HRESULT	DoJob(CString &errorCode);

	CString		m_Filename;
	DWORD		m_ItemId;
};

//////////////////////////////////////////////////////////////////////
//
//  CJobOpenPage
//
//////////////////////////////////////////////////////////////////////
class CGraphicSuiteView;

class CJobOpenPage : public CJob
{
	DECLARE_DYNCREATE(CJobOpenPage)

public:
	CJobOpenPage(CWnd *pNotifyMe = NULL, int priority = JOB_PRIORITY_NORMAL, BOOL bSkipOld = FALSE,
				FIMULTIBITMAP *pHandle= NULL, CGraphicSuiteView *pView= NULL, int page =0);
	virtual			~CJobOpenPage();
	
	virtual HRESULT	DoJob(CString &errorCode);

protected:

	FIMULTIBITMAP		*m_pHandle;
	CGraphicSuiteView	*m_pView;
	int					m_page;
};


//////////////////////////////////////////////////////////////////////
//
// CGraphicSuiteApp
//
//////////////////////////////////////////////////////////////////////
class CMultiDocTemplateGraphicSuite : public CMultiDocTemplate
{
	DECLARE_DYNAMIC(CMultiDocTemplateGraphicSuite)

public:
	CMultiDocTemplateGraphicSuite(UINT nIDResource, CRuntimeClass* pDocClass,
					CRuntimeClass* pFrameClass, CRuntimeClass* pViewClass);
	
	CDocument	*OpenDocumentFileSingle(const char *lpszPathName, FIBITMAP *hBitmap);
	CDocument	*OpenDocumentFileMulti(const char *lpszPathName, FIMULTIBITMAP *hBitmapMulti);
	CDocument	*OpenDocumentFileBoth(const char *lpszPathName, FIMULTIBITMAP *hBitmapMulti, FIBITMAP *hBitmap);
};

//////////////////////////////////////////////////////////////////////
//
// CGraphicSuiteApp
//
//////////////////////////////////////////////////////////////////////

class CGraphicSuiteApp : public CWinApp
{
public:
	CGraphicSuiteApp();

	virtual CDocument	*OpenDocumentFile(LPCTSTR lpszFileName);
	FIBITMAP			*OpenFromBitmap(HBITMAP hBitmap);
	
	// Multithreaded jobs
	void	Running(BOOL bRunning);
	BOOL	IsRunning(void);
	void	InitJobs(BOOL bInit);
	BOOL	AddJob(CJob *pJob, CWinThread *pThread, CRITICAL_SECTION *pCritSect, CListJobs &list);

	// Internal thread
	BOOL	AddJobIntern(CJob *pJob);
	void	StopCurrentJobIntern(void);
	void	StartRetrievalThreadIntern();
	void	StopRetrievalThreadIntern();

	void	AddRemoveMRU(const char *szLongPath, LPITEMIDLIST itemId, BOOL bOpen);

	CListJobs			m_listJobsIntern;
	CWinThread			*m_pThreadJobListIntern;
	CJob				*m_pCurrentJobIntern,
						*m_pAddingJob;		// durch g_crtSectJobAdding gekapselt
	BOOL				m_bRunning;


	CMultiDocTemplateGraphicSuite	*m_pDocTemplate;

protected:

	//{{AFX_VIRTUAL(CGraphicSuiteApp)
	public:
	virtual BOOL InitInstance();
	virtual int ExitInstance();
	//}}AFX_VIRTUAL

	//{{AFX_MSG(CGraphicSuiteApp)
	afx_msg void OnAppAbout();
	afx_msg void OnFileOpen();
	afx_msg void OnUpdateEditPaste(CCmdUI* pCmdUI);
	afx_msg void OnEditPaste();
	afx_msg void OnRes();
	afx_msg void OnUpdateRes(CCmdUI* pCmdUI);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}

#endif // !defined(AFX_GRAPHICSUITE_H__7E4994D3_9D63_4FFF_8730_805F1DC9F7C2__INCLUDED_)
