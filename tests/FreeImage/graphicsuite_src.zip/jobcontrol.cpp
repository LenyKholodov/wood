#include "stdafx.h"
#include "GraphicSuite.h"

#include "MainFrm.h"
#include "AFXPRIV.H"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

UINT	ThreadJobListIntern(LPVOID pParam);

UINT			ThreadJobAll(CListJobs *pJobListApp, CRITICAL_SECTION &critSection, BOOL bUpdateMainFrame, CJob * &pJobSetThis, BOOL &bJobKiller, BOOL bServerThread);
static BOOL		DoNextJob(CListJobs *pList, int &doneJobs, BOOL bUpdateMainFrame, CJob * &pJobSetThis, BOOL &bJobKiller, BOOL bServerThread);
static void		CopyListElements(CListJobs *pJobList, CListJobs *pList, CRITICAL_SECTION *pCriticalSection);
static void		DeleteListElements(CListJobs *pList, CRITICAL_SECTION *pCriticalSection);

extern CRITICAL_SECTION	g_crtSectJobListIntern;
extern CRITICAL_SECTION	g_crtSectJobAdding;
extern BOOL				m_JobKillerIntern;

//
// StartRetrievalThread
//
void CGraphicSuiteApp::StartRetrievalThreadIntern()
{
	m_pThreadJobListIntern = AfxBeginThread(ThreadJobListIntern, &m_listJobsIntern, THREAD_PRIORITY_NORMAL, 0, CREATE_SUSPENDED);
}

//
// StopRetrievalThread
//

void CGraphicSuiteApp::StopRetrievalThreadIntern()
{
//	AddJobIntern( new CJobStopCurrent(TRUE) );
}

//
// StopCurrentJob
//
void CGraphicSuiteApp::StopCurrentJobIntern(void)
{
	AddJobIntern( new CJobStopCurrent(FALSE) );
}

//
// AddJob
// RunJob
//

BOOL CGraphicSuiteApp::AddJobIntern(CJob *pJob)
{
	return AddJob(pJob, m_pThreadJobListIntern, &g_crtSectJobListIntern, m_listJobsIntern);
}

BOOL CGraphicSuiteApp::AddJob(CJob *pJob, CWinThread *pThread, CRITICAL_SECTION *pCritSect, CListJobs &list)
{
	if( !pJob )
		return FALSE;

	//
	// Thread wurde zerst�rt
	// => keine weiteren mehr aufnehmen
	//
	if( !pThread )
	{
		delete pJob;
		return FALSE;
	}

	#ifdef _TRACE_ON
		TRACE("   Created new %s at %p (priority=%d, bSkipOldAllowed=%d, pNotifyMe= %s (%p)\n", 
			pJob->GetRuntimeClass()->m_lpszClassName, pJob,
			pJob->GetPriority(), pJob->IsAllowedToSkipOld(),
			pJob->GetNotifier()->GetRuntimeClass()->m_lpszClassName, pJob->GetNotifier());
	#endif

	//
	// Script ausf�hren, noch im MainFrame-Thread!
	// 
	EnterCriticalSection(&g_crtSectJobAdding);
	{
		m_pAddingJob = pJob;
		pJob->RunJobScript();
		m_pAddingJob = NULL;
	}
	LeaveCriticalSection(&g_crtSectJobAdding);

	//
	// zur Liste dazu
	// 
	EnterCriticalSection(pCritSect);
	{
		list.AddTail(pJob);
	}
	LeaveCriticalSection(pCritSect);

	// Thread-Counter erh�hen

	#ifdef _TRACE_ON
	{
		TRACE("ResumeThread() from CGraphicSuiteApp::AddJob()\n");
	}
	#endif

	if( pJob->IsKindOf(RUNTIME_CLASS(CJobStopCurrent) ) )
		m_JobKillerIntern = TRUE;
	
	pThread->ResumeThread();

	return TRUE;
}

/////////////////////////////////////////////////////////////////////////////////////////////////////////
//
// Der Job-Thread
//
/////////////////////////////////////////////////////////////////////////////////////////////////////////

UINT ThreadJobListIntern(LPVOID pParam)
{
	GET_APP(pApp)
	return ThreadJobAll((CListJobs *) pParam, g_crtSectJobListIntern, FALSE, pApp->m_pCurrentJobIntern, m_JobKillerIntern, FALSE);
}

UINT ThreadJobAll(CListJobs *pJobListApp, CRITICAL_SECTION &critSection, BOOL bUpdateMainFrame, CJob * &pJobSetThis, BOOL &bJobKiller, BOOL bServerThread)
{
	CListJobs	*pList,
				jobList_Low,	// nur tempor�r, zum Sortieren der Jobs
				jobList_Normal,
				jobList_High,
				jobList_Extreme,
				jobList;		// die sortierte Jobliste
	POSITION	pos;
	CJob		*pJob;
	int			amount;
	CWinThread	*pThread = AfxGetThread();

	while( 1 )
	{
		//
		// Zuerst die Elemente sortiert 
		// dann in die Liste jobList �bernehmen
		// dazu dienen die tempor�ren Listen jobList_XXX
		// 

		// die alten tempor�ren Dinge raus
		jobList_Low.RemoveAll();
		jobList_Normal.RemoveAll();
		jobList_High.RemoveAll();
		jobList_Extreme.RemoveAll();
		jobList.RemoveAll();

		// die globale Liste durchgehen ...
		EnterCriticalSection(&critSection);
		pos = pJobListApp->GetHeadPosition();
		while( pos != NULL) 
		{
			pJob = pJobListApp->GetNext(pos);
			
			// ... in den Priorit�tslisten dazuf�gen
			pList = NULL;
			
			switch( pJob->GetPriority() ) 
			{
					case JOB_PRIORITY_LOW:		pList = &jobList_Low;		break;
					case JOB_PRIORITY_NORMAL:	pList = &jobList_Normal;	break;
					case JOB_PRIORITY_HIGH:		pList = &jobList_High;		break;
					case JOB_PRIORITY_EXTREME:	pList = &jobList_Extreme;	break;
					default:				
						{	
//							GET_APP(pApp)
//							pApp->_log.HandleErrorOrInfo(ERROR_EXIT_ADVICE, IDS_ERROR_JOBPRIORITY);
//							pList = &jobList_Extreme;	
						}
						break;
			}
			// in die Liste einh�ngen
			#ifdef _TRACE_ON
				TRACE("Adding %p to one of the lists\n", pJob);
			#endif
			pList->AddTail(pJob);
		}
		// ... und alle Element rausl�schen
		// es sollte kein Job verlorengehen, da alle Zugriffe 
		// mit g_crtSectJobList gekapselt sind!
		pJobListApp->RemoveAll();
		LeaveCriticalSection(&critSection);

		// jetzt sind alle Jobs in der lokalen Liste,
		// die globale ist leer

		// die eigentliche Jobliste aufbauen
		CopyListElements(&jobList, &jobList_Extreme, NULL);
		CopyListElements(&jobList, &jobList_High, NULL);
		CopyListElements(&jobList, &jobList_Normal, NULL);
		CopyListElements(&jobList, &jobList_Low, NULL);

		#ifdef _TRACE_ON
		{
			TRACE("List-Elements of jobList\n");
			pos = jobList.GetHeadPosition();
			while( pos != NULL )
				TRACE("%p\n", jobList.GetNext(pos));
		}
		#endif

		// jetzt steht in der jobList alle Jobs sortiert,
		// die wichtigsten bzw. �ltesten zuerst
		
		//
		//    ersten Job erledigen
		//    Diese Funktion erledigt den ersten Job
		//    und kehrt dann zur�ck
		//    Wenn Abbruch, dann Thread killen
		//
		if( !DoNextJob(&jobList, amount, bUpdateMainFrame, pJobSetThis, bJobKiller, bServerThread) || (amount==0) )
		{
			//delete all other jobs
			DeleteListElements(&jobList, NULL);
			DeleteListElements(pJobListApp, &critSection);

			// Thread killen
			return 1;
		}
		
		//
		// vermutlich waren mehr als 1 Job in der Liste
		// diese in die App-Liste zur�ckschreiben
		//
		CopyListElements(pJobListApp, &jobList, &critSection);

		// 
		// noch was zu tun => nochmal
		//
		EnterCriticalSection(&critSection);
		amount = pJobListApp->GetCount();
		LeaveCriticalSection(&critSection);
		if( amount == 0 )
		{
			#ifdef _TRACE_ON
			{
				TRACE("SuspendThread() from ThreadJobListBoth()\n");
			}
			#endif
			
			pThread->SuspendThread();
		}

	} // while( 1 )

	return 1;
}

/////////////////////////////////////////////////////////////////////////////////////////////////////////
//
// Listen- und Job-Verwaltung
//
/////////////////////////////////////////////////////////////////////////////////////////////////////////

void DeleteListElements(CListJobs *pList, CRITICAL_SECTION *pCriticalSection)
{
	CJob		*pJob;
	POSITION	pos;

	if(pCriticalSection)	
		EnterCriticalSection(pCriticalSection);

	pos = pList->GetHeadPosition();
	while( pos != NULL) 
	{
		pJob = pList->GetNext(pos);
		
		#ifdef _TRACE_ON
			TRACE("  Deleting job %p in DeleteListElements()\n", pJob);
		#endif
		
		delete pJob;
	}
	pList->RemoveAll();

	if(pCriticalSection)
		LeaveCriticalSection(pCriticalSection);
}

void CopyListElements(CListJobs *pJobList, CListJobs *pList, CRITICAL_SECTION *pCriticalSection)
{
	CJob		*pJob;
	POSITION	pos;

	if(pCriticalSection)	
		EnterCriticalSection(pCriticalSection);
	
	pos = pList->GetHeadPosition();
	while( pos != NULL) 
	{
		pJob = pList->GetNext(pos);
		pJobList->AddTail(pJob);
	}
	
	if(pCriticalSection)	
		LeaveCriticalSection(pCriticalSection);
}

//
// <-  Anzahl der get�tigten Jobs:
//     erledigte Jobs + zusammengefasste Jobs + gel�schte Jobs
//  
BOOL DoNextJob(CListJobs *pList, int &doneJobs, BOOL bUpdateMainFrame, CJob * &pJobSetThis, BOOL &bJobKiller, BOOL bServerThread)
{
	GET_APP(pApp)
	CMainFrame		*pFrame = ::GetMainFrame(FALSE);
	POSITION		pos;
	CJob			*pJobToDo,
					*pJob;
	BOOL			bSkipOldAllowed;
	CListJobs		listTodoNow,
					listTodoLater;
	int				amount = 1;
	BOOL			bMergeable,
					bReturn = TRUE;

	#ifdef _TRACE_ON
	{
		TRACE("->Entering DoNextJob()\n");
		TRACE("List-Elements of pList\n");
		pos = pList->GetHeadPosition();
		while( pos != NULL )
			TRACE("%p\n", pList->GetNext(pos));
	}
	#endif

	doneJobs = 0;

	// dieser Aufruf ist ohne CriticalSection m�glich,
	// weil in diese Liste vorher mit CriticalSection 
	// alles reinkopiert wurde

	// kein Element
	if(pList->IsEmpty()) 	
	{
		GET_APP(pApp)

		#ifdef _TRACE_ON
			TRACE("<-Leaving DoNextJob(FALSE): pList is empty \n");
		#endif
//		pApp->_log.HandleErrorOrInfo(ERROR_EXIT_ADVICE, IDS_JOBLIST_EMPTY);
		return FALSE;
	}

	//
	// erstes Element ist schon am l�ngsten drin oder hat h�chste Priorit�t,
	// das wird gemacht
	//
	pos				= pList->GetHeadPosition();
	pJobToDo		= pList->GetNext(pos);
	bSkipOldAllowed	= pJobToDo->IsAllowedToSkipOld();

	listTodoNow.AddTail(pJobToDo);

	//
	// vielleicht sind damit andere (�ltere) Jobs �berfl�ssig
	// dazu werden 2 Listen gemacht und in diese beiden verteilt
	//
	if( bSkipOldAllowed )
	{
		// den Rest durchsuchen, 
		while( pos != NULL )
		{
			pJob = pList->GetNext(pos);
			
			// l�schen, wenn:
			// - gleicher Typ
			// - der andere Job auch Flag m_bSkipOldAllowed
			// - der andere Job den gleichen Sender
			//
			bMergeable =	( pJob->GetRuntimeClass() == pJobToDo->GetRuntimeClass() )
						&&	( pJob->IsAllowedToSkipOld() )
						&&	( pJob->GetNotifier() == pJobToDo->GetNotifier() );

			if( bMergeable )
			{
				amount++;
				// gleicher Typ und l�schen �lterer erlaubt
				// d.h. es wird dieser Job, der aktueller ist, ausgef�hrt
				#ifdef _TRACE_ON
					TRACE("Added %p to listTodoNow\n", pJob);
				#endif
				listTodoNow.AddTail(pJob);
			}
			else	
			{
				#ifdef _TRACE_ON
					TRACE("Added %p to listTodoLater\n", pJob);
				#endif
				listTodoLater.AddTail(pJob);
			}
		}
	}
	else
	{
		// den Rest durchsuchen, 
		while( pos != NULL )
		{
			pJob = pList->GetNext(pos);
			#ifdef _TRACE_ON
				TRACE("Added %p to listTodoLater\n", pJob);
			#endif
			listTodoLater.AddTail(pJob);
		}		
	}

	#ifdef _TRACE_ON
	{
		if(amount > 1)
			TRACE("Merged %d jobs\n", amount);
		int		orgin = pList->GetCount(),
				delet = listTodoNow.GetCount(),
				later = listTodoLater.GetCount();
		ASSERT((delet+later) == orgin);

		TRACE("List-Elements of listTodoLater:\n");
		pos = listTodoLater.GetHeadPosition();
		while( pos != NULL )
			TRACE("%p\n", listTodoLater.GetNext(pos) );

		TRACE("List-Elements of listTodoNow:\n");
		pos = listTodoNow.GetHeadPosition();
		while( pos != NULL )
			TRACE("%p\n", listTodoNow.GetNext(pos));
	}
	#endif

	//
	// pList neu aufbauen
	//
	pList->RemoveAll();
	pos = listTodoLater.GetHeadPosition();
	while( pos != NULL )
	{
		pJob = listTodoLater.GetNext(pos);
		pList->AddTail(pJob);
	}

	//
	// den letzten Job von listTodoNow ausf�hren
	// da dieser der aktuellste ist
	// evtl. ist dies auch ein Job-Killer
	//
	
	doneJobs = listTodoNow.GetCount();

	pos = listTodoNow.GetTailPosition();
	pJobToDo = listTodoNow.GetPrev(pos);

	// alle Job von listTodoNow l�schen
	// bis auf den letzten
	while( pos != NULL )
	{
		// auch alle JobDaten l�schen,
		// da diese niemals zur�ckkommen
		//
		pJob = listTodoNow.GetPrev(pos);
		
		#ifdef _TRACE_ON
			TRACE("  Deleting job %p in DoNextJob() because it is merged to %p\n", pJob, pJobToDo);
		#endif
		delete pJob;
	}
	listTodoLater.RemoveAll();
	listTodoNow.RemoveAll();

	// dieses Element muss existieren !!
	ASSERT(pJobToDo);

	//
	//  Jetzt den Job erledigen
	// =========================
	//
	#ifdef _TRACE_ON
		TRACE("  Running job %p in DoNextJob()\n", pJobToDo);
	#endif

	// update menus
	pJobSetThis = pJobToDo;
	if( bUpdateMainFrame && IsValidWindow(pFrame) )
	{
		pFrame->SendNotifyMessage(WM_IDLEUPDATECMDUI, (WPARAM)TRUE, 0);
	}

	//
	// Do job
	//
	CString		errorCode;

	#ifdef _TRACE_ON
		TRACE("Running %s at %p \n", pJobToDo->GetRuntimeClass()->m_lpszClassName, pJobToDo);
	#endif

	// Animation starten
//	if( bServerThread && pFrame )
//		pFrame->AnimateTrayIcon(TRUE);
	
	HRESULT	jobResult;

	pApp->Running(TRUE);
	{
		jobResult = pJobToDo->DoJob(errorCode);
	}
	pApp->Running(FALSE);

	// Animation stoppen
//	if( bServerThread && pFrame )
//		pFrame->AnimateTrayIcon(FALSE);

	// Fehler
//	if( JOB_FAILED(jobResult) || (JOB_MSGTYPE(jobResult)!=ERROR_NULL) )
//		pApp->_log.HandleErrorOrInfo(JOB_MSGTYPE(jobResult), errorCode);
	
//	// Set Event (if available)
//	pApp->_jobdata.SetEvent(pJobToDo);

	// update menus
	pJobSetThis = NULL;
	if( bUpdateMainFrame && IsValidWindow(pFrame) )
	{
		pFrame->SendNotifyMessage(WM_IDLEUPDATECMDUI, (WPARAM)TRUE, 0);
	}

	// diesen Job jetzt auch l�schen
	#ifdef _TRACE_ON
		TRACE("  Deleting job %p in DoNextJob() after running\n", pJobToDo);
	#endif

	if( pJobToDo->IsKindOf(RUNTIME_CLASS(CJobStopCurrent) ) )
	{
		// Stop Thread
		if( ((CJobStopCurrent*)pJobToDo)->m_bStopThread )
			bReturn = FALSE;
	}

	delete pJobToDo;
	
	#ifdef _TRACE_ON
		TRACE("<-Leaving DoNextJob(%d)\n", bReturn);
	#endif

	// JobKiller zur�cksetzen
	bJobKiller = FALSE;

	return bReturn;
}

