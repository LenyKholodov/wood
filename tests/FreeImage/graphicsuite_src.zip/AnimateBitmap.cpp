#include "stdafx.h"
#include "AnimateBitmap.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
//
// CAnimateBmpCtrl
//
/////////////////////////////////////////////////////////////////////////////

BEGIN_MESSAGE_MAP(CAnimateBmpCtrl, CStatic)
	//{{AFX_MSG_MAP(CAnimateBmpCtrl)
	ON_WM_PAINT()
	ON_WM_ERASEBKGND()
	ON_WM_CREATE()
	ON_WM_TIMER()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

//
// Erzeugung
//
CAnimateBmpCtrl::CAnimateBmpCtrl()
{
	m_frameSizeX			= 0;
	m_frameSizeY			= 0;
	m_bSkipTiledImages		= TRUE;
	m_frameNrActual			= 0;
	m_frameNrDefault		= 0;
	m_bAnimating			= FALSE;
	m_ArrangementRightFirst	= TRUE;
	m_frameNrMax			= 0;
	m_TimerId				= 1;
	m_bUseDefaultBkColor	= TRUE;
	m_bContinueWithFirst	= TRUE;
	m_bGoingNext			= TRUE;
}

CAnimateBmpCtrl::~CAnimateBmpCtrl()
{
}

void CAnimateBmpCtrl::PreSubclassWindow() 
{
	CStatic::PreSubclassWindow();
	Initialize(TRUE);
}

int CAnimateBmpCtrl::OnCreate(LPCREATESTRUCT lpCreateStruct) 
{
	if (CStatic::OnCreate(lpCreateStruct) == -1)
		return -1;
	
	Initialize(FALSE);
	
	return 0;
}

void CAnimateBmpCtrl::Initialize(BOOL bIsSubclassed)
{
}

//
// Laden
//
BOOL CAnimateBmpCtrl::Load(const char *szFile, int frameSizeX, int frameSizeY, BOOL bSkipTiledImages, int arrangement)
{
	StopAnimation();

	if( !m_DIBSection.Load(szFile) )
		return FALSE;

	InitializeLoaded(frameSizeX, frameSizeY, bSkipTiledImages, arrangement);

	return TRUE;
}

BOOL CAnimateBmpCtrl::Load(UINT id, int frameSizeX, int frameSizeY, BOOL bSkipTiledImages, int arrangement)
{
	StopAnimation();

	if( !m_DIBSection.SetBitmap(id) )
		return FALSE;
	
	InitializeLoaded(frameSizeX, frameSizeY, bSkipTiledImages, arrangement);

	return TRUE;
}

void CAnimateBmpCtrl::InitializeLoaded(int frameSizeX, int frameSizeY, BOOL bSkipTiledImages, int arrangement)
{
	DWORD	stylesMove = SWP_NOOWNERZORDER | SWP_NOZORDER | SWP_SHOWWINDOW,
			stylesSize = stylesMove | SWP_NOMOVE;
	
	m_frameSizeX			= frameSizeX;
	m_frameSizeY			= frameSizeY;
	m_bSkipTiledImages		= bSkipTiledImages;
	m_frameNrActual			= 0;
	m_frameNrDefault		= 0;
	m_bAnimating			= FALSE;
	m_ArrangementRightFirst	= TRUE;
	m_frameNrMax			= 0;
	
	CalculateFrames();

	// Ausrichtung 
	// 0: links oben
	// 1: rechts oben
	// 2: links unten
	// 3: rechts unten
	//
	switch( arrangement )
	{
		case 0:		SetWindowPos(NULL, 0, 0, frameSizeX, frameSizeY, stylesSize);
					break;
		case 1:
		case 2:
		case 3:
		
		default:
		case -1:	break;
	}

	Invalidate();
}

//
// FrameVerwaltung
//
BOOL CAnimateBmpCtrl::SetDefaultFrame(int nr)
{
	if( nr>=0 && nr<m_frameNrMax )
	{
		m_frameNrDefault = nr;
		return TRUE;
	}
	else
		return FALSE;
}

BOOL CAnimateBmpCtrl::ShowFrame(int nr)
{
	int	oldVal = m_frameNrActual;
	m_frameNrActual = ( ( nr<0) ? m_frameNrDefault : nr);
	if( m_frameNrActual>=0 && m_frameNrActual<m_frameNrMax )
	{
		StopAnimation();
		Invalidate();
		return TRUE;
	}
	else
	{
		m_frameNrActual = oldVal;
		return FALSE;
	}
}

int CAnimateBmpCtrl::GetCurrentFrame(void)
{
	return m_frameNrActual;
}

int CAnimateBmpCtrl::GetDefaultFrame(void)
{
	return m_frameNrDefault;
}

void CAnimateBmpCtrl::SetFrameArrangementFirstRightThenDown(void)
{
	m_ArrangementRightFirst = TRUE;
}

void CAnimateBmpCtrl::SetFrameArrangementFirstDownThenRight(void)
{
	m_ArrangementRightFirst = FALSE;
}

void CAnimateBmpCtrl::CalculateFrames()
{
	int		bmpHeight	= m_DIBSection.GetHeight(),
			bmpWidth	= m_DIBSection.GetWidth();

	m_amountFramesRightInBmp = (bmpWidth / m_frameSizeX);
	if( !m_bSkipTiledImages && (bmpWidth%m_frameSizeX) )
		m_amountFramesRightInBmp++;

	m_amountFramesBottomInBmp = (bmpHeight / m_frameSizeY);
	if( !m_bSkipTiledImages && (bmpHeight%m_frameSizeY) )
		m_amountFramesBottomInBmp++;

	m_frameNrMax = m_amountFramesRightInBmp * m_amountFramesBottomInBmp;
}

BOOL CAnimateBmpCtrl::GetFramePosition(int frameNr, int &posX, int &posY)
{
	if( m_frameNrActual<0 || frameNr>=m_frameNrMax )
		return FALSE;
		
	if( m_ArrangementRightFirst )
	{
		posX = m_frameSizeX * (frameNr % m_amountFramesRightInBmp);
		posY = m_frameSizeY * (frameNr / m_amountFramesRightInBmp);
	}
	else
	{
		posX = m_frameSizeX * (frameNr / m_amountFramesBottomInBmp);
		posY = m_frameSizeY * (frameNr % m_amountFramesBottomInBmp);
	}

	return TRUE;
}

int CAnimateBmpCtrl::GetAmountFrames(void)
{
	return m_frameNrMax;
}

void CAnimateBmpCtrl::UseBkColor(COLORREF color)
{
	m_bUseDefaultBkColor = FALSE;
	m_bkColor = color;
}

void CAnimateBmpCtrl::UseDefaultBkColor(void)
{
	m_bUseDefaultBkColor = TRUE;
}

//
// Animation und Zeichnen
//

BOOL CAnimateBmpCtrl::Animate(int amountFullCycles, DWORD deltaInMS, BOOL bContinueWithFirst)
{
	if( !IsWindow(m_hWnd) )
		return FALSE;
	
	if( m_bAnimating )
		StopAnimation();

	m_bContinueWithFirst = bContinueWithFirst;
	m_bAnimating		= TRUE;
	m_timerTicksLeft	= ( (amountFullCycles<0) ? -1 : m_frameNrMax * amountFullCycles);

	m_TimerId = SetTimer(min(m_TimerId, 1), deltaInMS, NULL);
	
	if( !m_TimerId )
	{
		m_bAnimating		= FALSE;
		m_timerTicksLeft	= 0;
		return FALSE;
	}
	
	return TRUE;
}

BOOL CAnimateBmpCtrl::AnimateFrames(int amountFrames, DWORD deltaInMS)
{
	if( !IsWindow(m_hWnd) )
		return FALSE;

	if( amountFrames < 0 )
		return FALSE;

	if( m_bAnimating )
		StopAnimation();

	m_bAnimating		= TRUE;
	m_timerTicksLeft	= amountFrames;

	m_TimerId = SetTimer(min(m_TimerId, 1), deltaInMS, NULL);
	
	if( !m_TimerId )
	{
		m_bAnimating		= FALSE;
		m_timerTicksLeft	= 0;
		return FALSE;
	}
	
	return TRUE;
}

void CAnimateBmpCtrl::OnTimer(UINT nIDEvent) 
{
	static int id = 0;
	id++;
	//TRACE("\nTimer %d, event = %d", id, nIDEvent);

	if( nIDEvent == m_TimerId )
	{
		if( m_bContinueWithFirst )
		{
			m_frameNrActual++;
			if( m_frameNrActual >= m_frameNrMax )
				m_frameNrActual = 0;
		}
		else
		{
			if( m_bGoingNext )
			{
				m_frameNrActual++;
				if( m_frameNrActual >= m_frameNrMax )
				{
					m_frameNrActual = m_frameNrMax-2;
					m_bGoingNext = FALSE;
				}
			}
			else
			{
				m_frameNrActual--;
				if( m_frameNrActual <= 0 )
				{
					m_frameNrActual = 0;
					m_bGoingNext = TRUE;
				}
			}
		}

		Invalidate();

		if( m_timerTicksLeft >= 0 )
		{
			m_timerTicksLeft--;
			if( m_timerTicksLeft == 0)
			{
				StopAnimation();
			}
		}
	}
	else
		CStatic::OnTimer(nIDEvent);
}

void CAnimateBmpCtrl::Stop(BOOL bLeaveFrameAsIs)
{
	if( !IsWindow(m_hWnd) )
		return;

	StopAnimation();
	
	if( !bLeaveFrameAsIs )
		m_frameNrActual = m_frameNrDefault;

	Invalidate();
}

BOOL CAnimateBmpCtrl::IsAnimating(void)
{
	return 	m_bAnimating;
}

void CAnimateBmpCtrl::StopAnimation(void)
{
	if( !IsWindow(m_hWnd) )
		return;

	if( m_bAnimating )
	{
		//TRACE("\nKillTimer");
		KillTimer(m_TimerId);
		m_bAnimating = FALSE;
		m_bContinueWithFirst = TRUE;
		m_bGoingNext = TRUE;
		Invalidate();
	}
}

void CAnimateBmpCtrl::OnPaint() 
{
	int		posX,
			posY;

	if( !m_DIBSection.GetSafeHandle() )
		return;
	
	if( GetFramePosition(m_frameNrActual, posX, posY) )
	{
		//TRACE("\n Drawing frame %d", m_frameNrActual);

		CPaintDC	dc(this); // device context for painting

		//
		// Clipping auf das Fenster beschr�nken
		//
		CRgn	regionClip;
		CRect	rectClient,
				rectClipOld,
				rectClip;

		// neue ClipBox bestimmen
		GetClientRect(&rectClient);
		dc.GetClipBox(&rectClipOld);
		rectClip.IntersectRect(&rectClient, &rectClipOld);
		// und setzen
		regionClip.CreateRectRgnIndirect(rectClip);
		dc.SelectClipRgn(&regionClip); // set clip region to pane rect
	
		dc.OffsetViewportOrg(-posX, -posY);
		m_DIBSection.Draw(&dc, CPoint(0, 0));
	}
}

BOOL CAnimateBmpCtrl::OnEraseBkgnd(CDC* pDC) 
{
    HBRUSH	hBrush = NULL;

	if( !m_DIBSection.GetSafeHandle() )
		return CStatic::OnEraseBkgnd(pDC);

	if( m_bUseDefaultBkColor )
			hBrush =  (HBRUSH) GetClassLong(m_hWnd, GCL_HBRBACKGROUND);
	else	hBrush = ::CreateSolidBrush(m_bkColor);

	//
	// Clipping auf das Fenster beschr�nken
	//
	CRgn	regionClip;
	CRect	rectClient,
			rectClipOld,
			rectClip,
			rectImage;

	// neue ClipBox bestimmen
	GetClientRect(&rectClient);
	pDC->GetClipBox(&rectClipOld);
	rectClip.IntersectRect(&rectClient, &rectClipOld);
	// und setzen
	regionClip.CreateRectRgnIndirect(rectClip);
	pDC->SelectClipRgn(&regionClip); // set clip region to pane rect
	
	rectImage.SetRect(0,0, m_DIBSection.GetWidth(), m_DIBSection.GetHeight());

	// oben (incl. rechter und linker Rand
	if( rectImage.top > rectClient.top )
		::FillRect(pDC->GetSafeHdc(), CRect(rectClient.left, rectClient.top, rectClient.right, rectImage.top), hBrush);

	// unten (incl. rechter und linker Rand
	if( rectClient.bottom > rectImage.bottom )
		::FillRect(pDC->GetSafeHdc(), CRect(rectClient.left, rectImage.bottom, rectClient.right, rectClient.bottom), hBrush);

	// rechter Rand (nur neben dem Image)
	if( rectClient.right > rectImage.right )
		::FillRect(pDC->GetSafeHdc(), CRect(rectImage.right, rectImage.top, rectClient.right, rectImage.bottom), hBrush);
	
	// linker Rand (nur neben dem Image)
	if( rectImage.left > rectClient.left )
		::FillRect(pDC->GetSafeHdc(), CRect(rectClient.left, rectImage.top, rectImage.left, rectImage.bottom), hBrush);

	if( !m_bUseDefaultBkColor )
		::DeleteObject(hBrush);

    return TRUE;
}




/////////////////////////////////////////////////////////////////////////////
//
// CAnimateBmpThreadCtrl
//
/////////////////////////////////////////////////////////////////////////////

CAnimateBmpThreadCtrl::CAnimateBmpThreadCtrl()
{
	m_pParent	= NULL;
	m_pThread	= NULL;
	m_pCtrl		= NULL;
}

CAnimateBmpThreadCtrl::~CAnimateBmpThreadCtrl()
{
	if( m_pCtrl && IsWindow(m_pCtrl->m_hWnd) )
		m_pCtrl->SendMessage(WM_ANIMATE_BMP_EXIT);

	if( m_pThread )
	{
		TerminateThread(m_pThread->m_hThread, 1);
		delete m_pThread;
		m_pThread = NULL;
	}
}

BOOL CAnimateBmpThreadCtrl::Create(CWnd *pParent, CRect &rectCreate, UINT idWnd, UINT idBmp, int frameSizeX, int frameSizeY, BOOL bSkipTiledImages, int arrangement)
{
	// die Wnd-Sachen
	m_pParent	= pParent;
	m_rect		= rectCreate;
	m_idWnd		= idWnd;

	// die Animate-Sachen
	m_File.Empty();
	m_idBmp				= idBmp;
	m_FrameSizeX		= frameSizeX;
	m_FrameSizeY		= frameSizeY;
	m_bSkipTiledImages	= bSkipTiledImages;
	m_arrangement		= arrangement;

	m_pThread = AfxBeginThread(AnimateThreadProc, (LPVOID) this);
	return (m_pThread != NULL);
}

BOOL CAnimateBmpThreadCtrl::Create(CWnd *pParent, CRect &rectCreate, UINT idWnd, const char *szFile, int frameSizeX, int frameSizeY, BOOL bSkipTiledImages, int arrangement)
{
	// die Wnd-Sachen
	m_pParent	= pParent;
	m_rect		= rectCreate;
	m_idWnd		= idWnd;

	// die Animate-Sachen
	m_File				= szFile;
	m_idBmp				= 0;
	m_FrameSizeX		= frameSizeX;
	m_FrameSizeY		= frameSizeY;
	m_bSkipTiledImages	= bSkipTiledImages;
	m_arrangement		= arrangement;

	m_pThread = AfxBeginThread(AnimateThreadProc, (LPVOID) this);
	return (m_pThread != NULL);
}

void CAnimateBmpThreadCtrl::SetDefaultFrame(int nr)
{
	if( !m_pCtrl )	return;
	m_pCtrl->PostMessage(WM_ANIMATE_BMP_SET_DEFAULT_FRAME, nr);
}

void CAnimateBmpThreadCtrl::ShowFrame(int nr)
{
	if( !m_pCtrl )	return;
	m_pCtrl->PostMessage(WM_ANIMATE_BMP_SHOW_FRAME, nr);
}

void CAnimateBmpThreadCtrl::Animate(int amountFullCycles, DWORD deltaInMS, BOOL bContinueWithFirst)
{
	if( !m_pCtrl )	return;

	m_pCtrl->PostMessage(WM_ANIMATE_BMP_SET_CONTINUE_FIRST, bContinueWithFirst);
	m_pCtrl->PostMessage(WM_ANIMATE_BMP_ANIMATE, amountFullCycles, deltaInMS);
}

void CAnimateBmpThreadCtrl::AnimateFrames(int amountFrames, DWORD deltaInMS)
{
	if( !m_pCtrl )	return;
	m_pCtrl->PostMessage(WM_ANIMATE_BMP_ANIMATE_FRAMES, amountFrames, deltaInMS);
}

void CAnimateBmpThreadCtrl::Stop(BOOL bLeaveFrameAsIs)
{
	if( !m_pCtrl )	return;
	m_pCtrl->PostMessage(WM_ANIMATE_BMP_STOP, bLeaveFrameAsIs);
}

//
// Funktionen, die vom Thread aus aufgerufen werden
//
BOOL CAnimateBmpThreadCtrl::CreateControl(CAnimateBmpCtrl &animateCtrl)
{
	CWnd	*pWnd = &animateCtrl;
	
	if( !pWnd->Create(NULL, "", WS_CHILD|WS_VISIBLE, m_rect, m_pParent, m_idWnd) )
		return FALSE;
	
	if( m_idBmp )
	{
		if( !animateCtrl.Load(m_idBmp, m_FrameSizeX, m_FrameSizeY, m_bSkipTiledImages, m_arrangement) )
			return FALSE;
	}
	else if( !m_File.IsEmpty() )
	{
		if( !animateCtrl.Load(m_File, m_FrameSizeX, m_FrameSizeY, m_bSkipTiledImages, m_arrangement) )
			return FALSE;
	}
	else
		return FALSE;
	
	m_pCtrl = &animateCtrl;

	return TRUE;
}

//
// der Thread
//
UINT AnimateThreadProc(LPVOID pParam)
{
	BOOL					bContinueWithFirst = TRUE;
	CAnimateBmpThreadCtrl	*pThis = (CAnimateBmpThreadCtrl *) pParam;
	CAnimateBmpCtrl			animateCtrl;

	// Create the animation control.
	if( !pThis->CreateControl(animateCtrl) )
		return FALSE;

	// Pump message from the queue until the stop play message is received.
	MSG msg;
	while( GetMessage(&msg, NULL, 0, 0) && (msg.message!=WM_ANIMATE_BMP_EXIT) )
	{
		switch (msg.message)
		{
			case WM_ANIMATE_BMP_SET_DEFAULT_FRAME:
						animateCtrl.SetDefaultFrame((int) msg.wParam);
						break;

			case WM_ANIMATE_BMP_SHOW_FRAME:
						animateCtrl.ShowFrame((int) msg.wParam);
						break;

			case WM_ANIMATE_BMP_SET_CONTINUE_FIRST:
						bContinueWithFirst = (int) msg.wParam;
						break;

			case WM_ANIMATE_BMP_ANIMATE:
						animateCtrl.Animate((int) msg.wParam, (DWORD) msg.lParam, bContinueWithFirst);
						break;

			case WM_ANIMATE_BMP_ANIMATE_FRAMES:
						animateCtrl.AnimateFrames((int) msg.wParam, (DWORD) msg.lParam);
						break;

			case WM_ANIMATE_BMP_STOP:
						animateCtrl.Stop((BOOL) msg.wParam);
						break;
		}

		TranslateMessage(&msg);
		DispatchMessage(&msg);
	}

	AfxEndThread(1);
	return TRUE;
}
