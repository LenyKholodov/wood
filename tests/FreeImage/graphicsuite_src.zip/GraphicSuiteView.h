#if !defined(AFX_GRAPHICSUITEVIEW_H__939D3291_55FC_4247_AC71_78EC31D555CD__INCLUDED_)
#define AFX_GRAPHICSUITEVIEW_H__939D3291_55FC_4247_AC71_78EC31D555CD__INCLUDED_

#pragma once

//////////////////////////////////////////////////////////////////////
//
// CGraphicSuiteView
//
//////////////////////////////////////////////////////////////////////

class CGraphicSuiteView : public CScrollView
{
	DECLARE_DYNCREATE(CGraphicSuiteView)

public:
	CGraphicSuiteView();
	virtual ~CGraphicSuiteView();

	void				CreateMyPalette();
	CGraphicSuiteDoc	*GetDocument();
	void				RebuildScrollSizes(void);
	void				Initialize(void);
	void				SetZoom(double value);

protected:
    CPalette	*m_pPalette;
	BOOL		m_bPalCreated;
	double		m_Zoom,
				m_ZoomFactor;
	int			m_tiledHoriz,
				m_tiledVert;
	
public:
	virtual void	OnActivateView(BOOL bActivate, CView* pActivateView, CView* pDeactiveView);
	void			OnColors(unsigned colors, int param=0);
	void			OnUpdateCOLORS(CCmdUI* pCmdUI, unsigned colors);
	int				DoRealizePalette(BOOL bForceBackground);

	//{{AFX_VIRTUAL(CGraphicSuiteView)
	public:
	virtual void OnDraw(CDC* pDC);  // �berladen zum Zeichnen dieser Ansicht
	protected:
	virtual void OnInitialUpdate(); // das erste mal nach der Konstruktion aufgerufen
	virtual BOOL OnPreparePrinting(CPrintInfo* pInfo);
	virtual void OnBeginPrinting(CDC* pDC, CPrintInfo* pInfo);
	virtual void OnEndPrinting(CDC* pDC, CPrintInfo* pInfo);
	//}}AFX_VIRTUAL

protected:
	//{{AFX_MSG(CGraphicSuiteView)
	afx_msg void OnZoomIn();
	afx_msg void OnZoomOut();
	afx_msg void OnTile();
	afx_msg void OnColors1bit();
	afx_msg void OnCOLORS24bit();
	afx_msg void OnUpdateCOLORS24bit(CCmdUI* pCmdUI);
	afx_msg void OnColors256();
	afx_msg void OnUpdateColors256(CCmdUI* pCmdUI);
	afx_msg void OnCOLORS32bit();
	afx_msg void OnUpdateCOLORS32bit(CCmdUI* pCmdUI);
	afx_msg void OnUpdateCOLORS1bit(CCmdUI* pCmdUI);
	afx_msg void OnInfos();
	afx_msg void OnUpdateInfos(CCmdUI* pCmdUI);
	afx_msg void OnZoomLevel();
	afx_msg void OnUpdateZoomLevel(CCmdUI* pCmdUI);
	afx_msg BOOL OnQueryNewPalette();
	afx_msg void OnPaletteChanged(CWnd* pFocusWnd);
	afx_msg void OnPageFirst();
	afx_msg void OnPageLast();
	afx_msg void OnPageNext();
	afx_msg void OnPagePrev();
	afx_msg void OnUpdatePageFirst(CCmdUI* pCmdUI);
	afx_msg void OnUpdatePageLast(CCmdUI* pCmdUI);
	afx_msg void OnUpdatePageNext(CCmdUI* pCmdUI);
	afx_msg void OnUpdatePagePrev(CCmdUI* pCmdUI);
	afx_msg BOOL OnMouseWheel(UINT nFlags, short zDelta, CPoint pt);
	afx_msg LRESULT OnPageOpened(WPARAM wParam, LPARAM lParam);
	afx_msg void OnEditCopy();
	afx_msg void OnUpdateEditCopy(CCmdUI* pCmdUI);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}

#endif // !defined(AFX_GRAPHICSUITEVIEW_H__939D3291_55FC_4247_AC71_78EC31D555CD__INCLUDED_)
