#include "stdafx.h"
#include "GraphicSuite.h"

#include "MainFrm.h"
#include "ChildFrm.h"
#include "GraphicSuiteDoc.h"
#include "GraphicSuiteView.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

//////////////////////////////////////////////////////////////////////
//
// CJob
//
//////////////////////////////////////////////////////////////////////

IMPLEMENT_DYNCREATE(CJob, CCmdTarget)

BEGIN_MESSAGE_MAP(CJob, CCmdTarget)
	//{{AFX_MSG_MAP(CJob)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

CJob::CJob(CWnd *pNotifyMe,	// = NULL
		   int priority,			// = JOB_PRIORITY_NORMAL
		   BOOL bSkipOld)			// = FALSE
{
	m_pNotifyMe			= pNotifyMe;
	m_dPriority			= priority;
	m_bSkipOldAllowed	= bSkipOld;
	GET_APP(m_pApp)

	#ifdef _TRACE_ON
		TRACE("Created %s at %p \n", GetRuntimeClass()->m_lpszClassName, this);
	#endif
}

CJob::~CJob()
{
}

BOOL CJob::RunJobScript(void)
{
	return FALSE;
}

HRESULT CJob::DoJob(CString &errorCode)
{
	return JOB_CREATE_CLIENT_ERROR(JOB_CODE_NOTIMPL);
}

BOOL CJob::NotifyCaller(UINT message, WPARAM wParam, LPARAM lParam)
{
	BOOL	bIsWindow;

	bIsWindow = IsValidWindow(m_pNotifyMe);

	if( !bIsWindow )
	{
		CWnd	*pSendTo;

		pSendTo = AfxGetApp()->GetMainWnd();
		bIsWindow = IsValidWindow(pSendTo);
	}

	if( !bIsWindow )	
		return FALSE;
	else
		return ( ::IsWindow(m_pNotifyMe->m_hWnd)
						? (m_pNotifyMe->SendNotifyMessage(message, wParam, lParam) ) 
						: FALSE
				);
}

BOOL CJob::NotifyMainFrame(BOOL bForceNow, UINT message, WPARAM wParam, LPARAM lParam)
{
	CMainFrame	*pFrame = ::GetMainFrame(FALSE);
	
	if( IsValidWindow(pFrame) )
	{
		if( bForceNow )
				pFrame->PostMessage(message, wParam, lParam);
		else	pFrame->SendNotifyMessage(message, wParam, lParam);
		return TRUE;
	}
	else
		return FALSE;
}

//
// Progress-Steuerung
//
/*
void CJob::SetProgressText(CString &str)
{
	GET_APP(pApp)
	CProgressWnd	*pProgressFrame = pApp->_frames.m_pProgressFrame;
	pProgressFrame->SetText(str);
}

void CJob::SetProgressTitle(CString &str)
{
	GET_APP(pApp)
	CProgressWnd	*pProgressFrame = pApp->_frames.m_pProgressFrame;
	pProgressFrame->SetTitle(str);
}

void CJob::SetProgressMax(unsigned int max)
{
	GET_APP(pApp)
	CProgressWnd	*pProgressFrame = pApp->_frames.m_pProgressFrame;
	pProgressFrame->SetRange(0, max);
}

void CJob::ShowProgress(BOOL bShow)
{
	GET_APP(pApp)
	CProgressWnd	*pProgressFrame = pApp->_frames.m_pProgressFrame;
	CMainFrame		*pFrame = ::GetMainFrame(FALSE);

	if( !pProgressFrame )
		return;

	if( bShow )
	{
		pProgressFrame->SetText("");
		pProgressFrame->SetCancel(FALSE);
		pProgressFrame->SetPos(0);
		pProgressFrame->Show();
	}
	else
	{
		pProgressFrame->Hide();
	}
}

BOOL CJob::SetProgressPos(unsigned int val)
{
	GET_APP(pApp)
	CProgressWnd	*pProgressFrame = pApp->_frames.m_pProgressFrame;

	pProgressFrame->SetPos(val);
	return !pProgressFrame->Cancelled();
}
*/

//////////////////////////////////////////////////////////////////////
//
// CJobStopCurrent
//
//////////////////////////////////////////////////////////////////////

IMPLEMENT_DYNCREATE(CJobStopCurrent, CJob)

CJobStopCurrent::CJobStopCurrent(BOOL bStopThread)
	: CJob(AfxGetApp()->GetMainWnd(), JOB_PRIORITY_EXTREME, TRUE)
{
	m_bStopThread = bStopThread;
}

CJobStopCurrent::~CJobStopCurrent()
{
}

HRESULT CJobStopCurrent::DoJob(CString &errorCode)
{
	return JOB_CODE_OK;
}

//////////////////////////////////////////////////////////////////////
//
// CJobOpenDocument
//
//////////////////////////////////////////////////////////////////////

IMPLEMENT_DYNCREATE(CJobOpenDocument, CJob)

CJobOpenDocument::CJobOpenDocument(CWnd *pNotifyMe, int priority, BOOL bSkipOld, 
								CString &filename, DWORD itemId)
	: CJob(pNotifyMe, priority, bSkipOld)
	, m_Filename(filename)
	, m_ItemId(itemId)
{
}

CJobOpenDocument::~CJobOpenDocument()
{
}

HRESULT CJobOpenDocument::DoJob(CString &errorCode)
{
	GET_APP(pApp)

	FREE_IMAGE_FORMAT	fif = FIF_UNKNOWN;
	char				szLongPath[2*_MAX_PATH] = { 0 };
	BOOL				bSucees			= FALSE;
	FIBITMAP			*handleFI		= NULL;
	FIMULTIBITMAP		*handleFI_MP	= NULL;
	int					pageCount		= 1;

	try
	{
		fif = FreeImage_GetFIFFromFilename(m_Filename);
		if( fif != FIF_UNKNOWN )
		{
			handleFI_MP = FreeImage_OpenMultiBitmap(fif, m_Filename, FALSE, FALSE, FALSE);

			if( handleFI_MP )
			{
				pageCount = FreeImage_GetPageCount(handleFI_MP);
				if(pageCount<=1)
				{
					FreeImage_CloseMultiBitmap(handleFI_MP);
					handleFI_MP = NULL;
				}
			}
			
			if( !handleFI_MP )
				handleFI = FreeImage_Load(fif, m_Filename);
		}

		bSucees = (handleFI!=NULL) || (handleFI_MP!=NULL);
	}
	catch(...)
	{
		if( handleFI )		FreeImage_Unload(handleFI);
		if( handleFI_MP )	FreeImage_CloseMultiBitmap(handleFI_MP);
		
		handleFI = NULL;
		handleFI_MP = NULL;

		bSucees = FALSE;
	}

	if( handleFI ) 		
		NotifyMainFrame(FALSE, WM_FILE_OPENED_SINGLE, m_ItemId, (LPARAM) handleFI);
	else if( handleFI_MP ) 
		NotifyMainFrame(FALSE, WM_FILE_OPENED_MULTI, m_ItemId, (LPARAM) handleFI_MP);

	if( fif == FIF_UNKNOWN || !bSucees )
		return JOB_CREATE_CLIENT_ERROR(JOB_CODE_DATACORRUPT);

	return JOB_CODE_OK;
}


//////////////////////////////////////////////////////////////////////
//
// CJobOpenPage
//
//////////////////////////////////////////////////////////////////////

IMPLEMENT_DYNCREATE(CJobOpenPage, CJob)

CJobOpenPage::CJobOpenPage(CWnd *pNotifyMe, int priority, BOOL bSkipOld,
							FIMULTIBITMAP *pHandle, CGraphicSuiteView *pView, int page)
	: CJob(pNotifyMe, priority, bSkipOld)
	, m_pHandle(pHandle)
	, m_pView(pView)
	, m_page(page)

{
}

CJobOpenPage::~CJobOpenPage()
{
}

HRESULT CJobOpenPage::DoJob(CString &errorCode)
{
	if( !IsValidWindow(m_pView) || !m_pHandle )
		return JOB_CREATE_CLIENT_ERROR(JOB_CODE_DATACORRUPT);

	FIBITMAP *pHandle = FreeImage_LockPage(m_pHandle, m_page);

	m_pView->PostMessage(WM_PAGE_OPENED, m_page, (LPARAM) pHandle);

	return JOB_CODE_OK;
}

