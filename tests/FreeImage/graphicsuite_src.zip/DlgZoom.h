#if !defined(AFX_DLGZOOM_H__F64CA78C_A6AE_41B5_8D0F_AF5FF1E99292__INCLUDED_)
#define AFX_DLGZOOM_H__F64CA78C_A6AE_41B5_8D0F_AF5FF1E99292__INCLUDED_

#pragma once

//////////////////////////////////////////////////////////////////////
//
// CDlgZoom
//
//////////////////////////////////////////////////////////////////////

class CDlgZoom : public CDialog
{
public:
	CDlgZoom(CWnd* pParent = NULL, double zoom=1.0, double factor=1.1);

	//{{AFX_DATA(CDlgZoom)
	enum { IDD = IDD_DIALOG_ZOOM };
	double	m_editFactor;
	double	m_editValue;
	//}}AFX_DATA

	//{{AFX_VIRTUAL(CDlgZoom)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);
	//}}AFX_VIRTUAL

	//{{AFX_MSG(CDlgZoom)
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}

#endif // AFX_DLGZOOM_H__F64CA78C_A6AE_41B5_8D0F_AF5FF1E99292__INCLUDED_
