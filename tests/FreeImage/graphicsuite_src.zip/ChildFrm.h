#if !defined(AFX_CHILDFRM_H__E6BF2FC8_D2BF_4DB0_B87C_78A0F0171E35__INCLUDED_)
#define AFX_CHILDFRM_H__E6BF2FC8_D2BF_4DB0_B87C_78A0F0171E35__INCLUDED_

#pragma once

//////////////////////////////////////////////////////////////////////
//
// CChildFrame
//
//////////////////////////////////////////////////////////////////////

class CChildFrame : public CMDIChildWnd
{
	DECLARE_DYNCREATE(CChildFrame)

public:
	CChildFrame();
	virtual ~CChildFrame();

	//{{AFX_VIRTUAL(CChildFrame)
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	//}}AFX_VIRTUAL

protected:
	//{{AFX_MSG(CChildFrame)
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}

#endif // !defined(AFX_CHILDFRM_H__E6BF2FC8_D2BF_4DB0_B87C_78A0F0171E35__INCLUDED_)
