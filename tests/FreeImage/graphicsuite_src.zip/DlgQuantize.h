#if !defined(AFX_DLGQUANTIZE_H__29B93214_14B4_40F9_A096_91052D7A2EF7__INCLUDED_)
#define AFX_DLGQUANTIZE_H__29B93214_14B4_40F9_A096_91052D7A2EF7__INCLUDED_

#pragma once

//////////////////////////////////////////////////////////////////////
//
// CDlgQuantize
//
//////////////////////////////////////////////////////////////////////

class CDlgQuantize : public CDialog
{
public:
	CDlgQuantize(CWnd* pParent = NULL);   // Standardkonstruktor

	//{{AFX_DATA(CDlgQuantize)
	enum { IDD = IDD_DIALOG_QUANTIZE };
	int		m_type;
	//}}AFX_DATA


	//{{AFX_VIRTUAL(CDlgQuantize)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV-Unterst�tzung
	//}}AFX_VIRTUAL

	//{{AFX_MSG(CDlgQuantize)
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}

#endif // AFX_DLGQUANTIZE_H__29B93214_14B4_40F9_A096_91052D7A2EF7__INCLUDED_
