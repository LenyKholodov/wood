#if !defined(AFX_STDAFX_H__406286A8_E986_4A6A_B883_D6BD306EB432__INCLUDED_)
#define AFX_STDAFX_H__406286A8_E986_4A6A_B883_D6BD306EB432__INCLUDED_

#pragma once

#define VC_EXTRALEAN		// Selten verwendete Teile der Windows-Header nicht einbinden

#include <afxwin.h>         // MFC-Kern- und -Standardkomponenten
#include <afxext.h>         // MFC-Erweiterungen
#include <afxdtctl.h>		// MFC-Unterst�tzung f�r allgemeine Steuerelemente von Internet Explorer 4
#ifndef _AFX_NO_AFXCMN_SUPPORT
#include <afxcmn.h>			// MFC-Unterst�tzung f�r g�ngige Windows-Steuerelemente
#endif // _AFX_NO_AFXCMN_SUPPORT

#include <afxtempl.h>
#include <afxcoll.h>
#include <Afxmt.h>			// Multiple-Threads

#pragma warning( disable : 4786)
#include <vector>
#include <utility>
#include <algorithm>
#include <deque>
#include <strstream>
#include <deque>
#include <string>
using namespace std ;

#include "./freeimage/freeimage.h"


//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ f�gt unmittelbar vor der vorhergehenden Zeile zus�tzliche Deklarationen ein.

#endif // !defined(AFX_STDAFX_H__406286A8_E986_4A6A_B883_D6BD306EB432__INCLUDED_)
