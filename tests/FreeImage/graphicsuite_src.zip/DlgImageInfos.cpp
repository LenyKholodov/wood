#include "stdafx.h"
#include "graphicsuite.h"

#include "DlgImageInfos.h"

#include "GraphicSuiteDoc.h"


#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

//////////////////////////////////////////////////////////////////////
//
// CDlgImageInfos
//
//////////////////////////////////////////////////////////////////////

BEGIN_MESSAGE_MAP(CDlgImageInfos, CDialog)
	//{{AFX_MSG_MAP(CDlgImageInfos)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

CDlgImageInfos::CDlgImageInfos(CWnd* pParent, FIBITMAP *pBitmap, FIMULTIBITMAP *pMP, CDocument *pDoc)
	: CDialog(CDlgImageInfos::IDD, pParent)
{
	//{{AFX_DATA_INIT(CDlgImageInfos)
	//}}AFX_DATA_INIT

	m_pBitmap	= pBitmap;
	m_pBitmapMP	= pMP;
	m_pDoc		= pDoc;
}

void CDlgImageInfos::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CDlgImageInfos)
	//}}AFX_DATA_MAP
}

char FormatByteSize(double nummer, const char *post, CString &erg)
{
	double	fKiloByte  = 1024.0,
			fMegaByte  = 1024.0 * fKiloByte,
			fGigaByte  = 1024.0 * fMegaByte,
			fTerraByte = 1024.0 * fGigaByte;
	char	prefix;
	
	if( nummer-fTerraByte >= 0 )
	{
		// Terra-Bereich
		erg.Format("%.2f Terra-Bytes", nummer/fTerraByte);
		prefix = 'T';
	}
	if( nummer-fGigaByte >= 0 )
	{
		// Giga-Bereich
		erg.Format("%.2f GB", nummer/fGigaByte);
		prefix = 'G';
	}
	else if( nummer-fMegaByte >= 0 )
	{
		// Mega
		erg.Format("%.2f MB", nummer/fMegaByte);
		prefix = 'M';
	}
	else if( nummer-fKiloByte >= 0 )
	{
		// Kilo
		erg.Format("%.2f kB", nummer/fKiloByte);
		prefix = 'k';
	}
	else
	{
		erg.Format("%.0f Bytes", nummer);
		prefix = '\0';
	}

	if( post && *post )
		erg += post;

	return prefix;
}

BOOL CDlgImageInfos::OnInitDialog() 
{
	CString	msg,
			msg1,
			msg2;

	CDialog::OnInitDialog();
	
	if( !m_pBitmap )
		return FALSE;
	
	//
	// filename
	//
	msg = m_pDoc->GetPathName();
	GetDlgItem(IDC_STATIC_FILE)->SetWindowText(msg);

	//
	// page
	//
	if( m_pBitmapMP )
	{
		CGraphicSuiteDoc	*pDoc2 = (CGraphicSuiteDoc*) m_pDoc;
		msg.Format(IDS_INFO_PAGE, 1+pDoc2->GetCurrPage(), pDoc2->GetPageCount());
	}
	else
		msg.Format(IDS_INFO_PAGE, 1, 1);
	GetDlgItem(IDC_STATIC_PAGE)->SetWindowText(msg);
	

	//
	// colorType
	//
	unsigned	colors = FreeImage_GetBPP(m_pBitmap),
				used   = FreeImage_GetColorsUsed(m_pBitmap);
	int			type   = FreeImage_GetColorType(m_pBitmap);
	
	msg1.Format("%d bit", colors);
	
	switch(type)
	{
		case FIC_MINISWHITE:	msg2 = "min value is white";	break;
		case FIC_MINISBLACK:	msg2 = "min value is black";	break;
		case FIC_RGB:			msg2 = "RGB color model";	break;
		case FIC_PALETTE:		msg2.Format("color map indexed (palette with %d entries)", 
											used);	break;
		case FIC_RGBALPHA:		msg2 = "RGB color model with alpha channel";	break;
		default:				msg2 = "?";	break;
	}

	msg.Format("%s:  %s", msg1, msg2);
	GetDlgItem(IDC_STATIC_COLORS)->SetWindowText(msg);

	//
	// resolution
	//
	unsigned	resXMetric = FreeImage_GetDotsPerMeterX(m_pBitmap),
				resYMetric = FreeImage_GetDotsPerMeterY(m_pBitmap);
	double		resX = resXMetric,
				resY = resYMetric;

	if( resXMetric > 0 )
	{
		msg.Format("%.0f", resX);
		GetDlgItem(IDC_STATIC_RES_X_M)->SetWindowText(msg);

		resX *= (2.54/100.0);
		msg.Format("%.1f", resX);
		GetDlgItem(IDC_STATIC_RES_X)->SetWindowText(msg);
	}

	if( resYMetric > 0 )
	{	
		msg.Format("%.0f", resY);
		GetDlgItem(IDC_STATIC_RES_Y_M)->SetWindowText(msg);
	
		resY *= (2.54/100.0);
		msg.Format("%.1f", resY);
		GetDlgItem(IDC_STATIC_RES_Y)->SetWindowText(msg);
	}
	
	//
	// size
	//
	unsigned	width  = FreeImage_GetWidth(m_pBitmap),
				height = FreeImage_GetHeight(m_pBitmap);
	double		sizeX,
				sizeY;

	msg.Format("%u", width);	GetDlgItem(IDC_STATIC_SIZE_X_PIXEL)->SetWindowText(msg);
	msg.Format("%u", height);	GetDlgItem(IDC_STATIC_SIZE_Y_PIXEL)->SetWindowText(msg);

	if( resXMetric > 0 )
	{
		sizeX = 100.0* width  / resXMetric;
		msg.Format("%.2f", sizeX);	
		GetDlgItem(IDC_STATIC_SIZE_X_METRIC)->SetWindowText(msg);

		sizeX = width  / resX;
		msg.Format("%.2f", sizeX);	
		GetDlgItem(IDC_STATIC_SIZE_X)->SetWindowText(msg);
	}

	if( resYMetric > 0 )
	{
		sizeY = 100.0* height / resYMetric;
		msg.Format("%.2f", sizeY);	
		GetDlgItem(IDC_STATIC_SIZE_Y_METRIC)->SetWindowText(msg);

		sizeY = height / resY;
		msg.Format("%.2f", sizeY);	
		GetDlgItem(IDC_STATIC_SIZE_Y)->SetWindowText(msg);
	}
	
	//
	// Memory
	// 
	unsigned bytes = FreeImage_GetDIBSize(m_pBitmap);
	FormatByteSize(bytes, NULL, msg);
	GetDlgItem(IDC_STATIC_MEM)->SetWindowText(msg);
	
	return TRUE;
}
