// stdafx.cpp : Quelltextdatei, die nur die Standard-Includes einbindet
//	GraphicSuite.pch ist die vorcompilierte Header-Datei
//	stdafx.obj enth�lt die vorcompilierte Typinformation

#include "stdafx.h"



