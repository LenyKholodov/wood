#if !defined(AFX_DLGTILE_H__6F26C50F_D0B8_4ED5_941A_F8C90E347849__INCLUDED_)
#define AFX_DLGTILE_H__6F26C50F_D0B8_4ED5_941A_F8C90E347849__INCLUDED_

#pragma once

//////////////////////////////////////////////////////////////////////
//
// CDlgTile
//
//////////////////////////////////////////////////////////////////////

class CDlgTile : public CDialog
{
public:
	CDlgTile(CWnd* pParent = NULL);   // Standardkonstruktor

	//{{AFX_DATA(CDlgTile)
	enum { IDD = IDD_DIALOG_TILE };
	UINT	m_dHor;
	UINT	m_dVert;
	//}}AFX_DATA

	//{{AFX_VIRTUAL(CDlgTile)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV-Unterst�tzung
	//}}AFX_VIRTUAL

protected:
	//{{AFX_MSG(CDlgTile)
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}

#endif // AFX_DLGTILE_H__6F26C50F_D0B8_4ED5_941A_F8C90E347849__INCLUDED_
