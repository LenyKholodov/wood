#include "stdafx.h"
#include "GraphicSuite.h"

#include "./pxshlapi/PxShlAPI.h"

#include "GraphicSuiteDoc.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

//////////////////////////////////////////////////////////////////////
//
// CGraphicSuiteDoc
//
//////////////////////////////////////////////////////////////////////

IMPLEMENT_DYNCREATE(CGraphicSuiteDoc, CDocument)

BEGIN_MESSAGE_MAP(CGraphicSuiteDoc, CDocument)
	//{{AFX_MSG_MAP(CGraphicSuiteDoc)
	ON_COMMAND(ID_FILE_SAVE_AS, OnFileSaveAs)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

CGraphicSuiteDoc::CGraphicSuiteDoc()
{
	m_handleFI		= NULL;
	m_handleFI_MP	= NULL;
	m_pageCount		= 0;
	m_currPage		= 0;
}

CGraphicSuiteDoc::~CGraphicSuiteDoc()
{
	DeleteContents();
}

FIBITMAP *CGraphicSuiteDoc::GetFIBitmap(void)
{
	return m_handleFI;
}

FIMULTIBITMAP *CGraphicSuiteDoc::GetFIBitmapMP(void)
{
	return m_handleFI_MP;
}

int CGraphicSuiteDoc::GetPageCount()
{
	int		pageCount = 0;

	if( m_handleFI_MP )
		pageCount = m_pageCount;
	else if(m_handleFI)
		pageCount = 1;

	return pageCount;
}

int CGraphicSuiteDoc::GetCurrPage()
{
	int		currPage = 0;

	if( m_handleFI_MP )
		currPage = m_currPage;
	else if(m_handleFI)
		currPage = 0;

	return currPage;
}

BOOL CGraphicSuiteDoc::SetPage(int page)
{
	GET_APP(pApp)

	int		currPage = 0;

	if( !m_handleFI_MP )
		return FALSE;

	if( page < 0 || page>=m_pageCount )
		return FALSE;

	if( page==m_currPage )
		return FALSE;

	m_currPage = page;

	if( !m_mapHandles.Lookup((void*)m_currPage, (void *&)m_handleFI) )
	{
		CJobOpenPage	*pJob = new CJobOpenPage(AfxGetApp()->GetMainWnd(), JOB_PRIORITY_HIGH, FALSE,
												m_handleFI_MP, GetFirstView(), m_currPage);
		pApp->AddJobIntern(pJob);
		return FALSE;
	}

	return TRUE;
}

void CGraphicSuiteDoc::DeleteContents() 
{
	if( m_handleFI_MP )
	{
//		if( m_handleFI )
//			FreeImage_UnlockPage(m_handleFI_MP, m_handleFI, false);
		FreeImage_CloseMultiBitmap(m_handleFI_MP);
	}
	else if( m_handleFI )
		FreeImage_Unload(m_handleFI);

	m_handleFI_MP	= NULL;
	m_handleFI		= NULL;
	m_pageCount		= 0;
	m_currPage		= 0;

	m_mapHandles.RemoveAll();

	CDocument::DeleteContents();
}

BOOL CGraphicSuiteDoc::OnNewDocument()
{
	if (!CDocument::OnNewDocument())
		return FALSE;

	return TRUE;
}

void CGraphicSuiteDoc::Serialize(CArchive& ar)
{
/*
	if (ar.IsStoring())
	{
	}
	else
	{
	}
*/
}

CGraphicSuiteView *CGraphicSuiteDoc::GetFirstView()
{
	POSITION	pos;

	pos = GetFirstViewPosition();
	if( pos )
		return (CGraphicSuiteView*) GetNextView(pos);

	return NULL;
}

BOOL CGraphicSuiteDoc::OnOpenDocument(LPCTSTR lpszPathName, FIMULTIBITMAP *hBitmapMulti, FIBITMAP *hBitmap)
{
	GET_APP(pApp)

	DeleteContents();

	m_handleFI		= hBitmap;
	m_handleFI_MP	= hBitmapMulti;

	if( m_handleFI_MP ) 
	{
		m_pageCount = FreeImage_GetPageCount(m_handleFI_MP);
		
		CJobOpenPage	*pJob = new CJobOpenPage(AfxGetApp()->GetMainWnd(), JOB_PRIORITY_HIGH, FALSE,
												m_handleFI_MP, GetFirstView(), 0);
		pApp->AddJobIntern(pJob);
		return TRUE;
	}
	
	return (m_handleFI != NULL);
}

void CGraphicSuiteDoc::OnSetPage(FIBITMAP *pHandle, int page)
{
	m_currPage	= page;
	m_handleFI  = pHandle;
	
	m_mapHandles.SetAt((void*)m_currPage, m_handleFI);
}

void CGraphicSuiteDoc::OnFileSaveAs() 
{
	CString				filter,
						szDest;
	DWORD				dwFlags = OFN_OVERWRITEPROMPT | OFN_EXPLORER | OFN_LONGNAMES | OFN_PATHMUSTEXIST | OFN_HIDEREADONLY;
	FREE_IMAGE_FORMAT	fif;
	BOOL				bErg;

	if( !m_handleFI )
		return;

	// Pfad bestimmen !!
	filter.LoadString(IDS_STRING_FILTER_GRAPHICS);
	
	CFileDialog	dlg(FALSE, NULL, szDest, dwFlags, filter, AfxGetMainWnd());

	if(  dlg.DoModal() != IDOK)
		return;
	
	CWaitCursor	wait;
	fif = FreeImage_GetFIFFromFilename(dlg.GetPathName());
	if( fif == FIF_UNKNOWN )
	{
		AfxMessageBox("Unknown type.");
		return;
	}

	bErg = FALSE;
	try
	{
		bErg = FreeImage_Save(fif, m_handleFI, dlg.GetPathName());
	}
	catch(...)
	{
	}
	
	if( !bErg )
		AfxMessageBox("Failed saving !");
}
