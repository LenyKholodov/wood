//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by GraphicSuite.rc
//
#define IDD_ABOUTBOX                    100
#define IDR_MAINFRAME                   128
#define IDR_SUITETYPE                   129
#define IDS_STRING_FILTER_GRAPHICS      130
#define IDD_DIALOG_TILE                 130
#define IDS_CONVERT_FAILED              131
#define IDD_DIALOG_QUANTIZE             132
#define IDS_OPEN_ERROR                  132
#define IDD_DIALOG_INFOS                133
#define IDS_INFO_PAGE                   133
#define IDB_BITMAP_ANIMATE              133
#define IDD_DIALOG_ZOOM                 134
#define ID_INDICATOR_ANIMATION          134
#define IDB_BITMAP_TEST                 134
#define IDC_EDIT_HOR                    1000
#define IDC_EDIT_VERT                   1001
#define IDC_RADIO_CLASSIC               1001
#define IDC_RADIO_NEURONAL              1002
#define IDC_STATIC_COLORS               1002
#define IDC_STATIC_SIZE_X_PIXEL         1003
#define IDC_EDIT_VALUE                  1003
#define IDC_STATIC_SIZE_Y_PIXEL         1004
#define IDC_EDIT_FACTOR                 1004
#define IDC_STATIC_FREEIMAGE_VERSION    1004
#define IDC_STATIC_RES_X                1005
#define IDC_STATIC_FREEIMAGE_COPYRIGHT  1005
#define IDC_STATIC_RES_Y                1006
#define IDC_STATIC_RES_X_M              1007
#define IDC_STATIC_RES_Y_M              1008
#define IDC_STATIC_SIZE_X_METRIC        1009
#define IDC_STATIC_SIZE_Y_METRIC        1010
#define IDC_STATIC_SIZE_X               1011
#define IDC_STATIC_SIZE_Y               1012
#define IDC_STATIC_MEM                  1013
#define IDC_STATIC_FILE                 1014
#define IDC_STATIC_PAGE                 1015
#define ID_TILE                         32771
#define ID_COLORS_24bit                 32772
#define ID_COLORS_32bit                 32773
#define ID_COLORS_256                   32774
#define ID_ZOOM_IN                      32776
#define ID_ZOOM_OUT                     32777
#define ID_COLORS_1bit                  32778
#define ID_INFOS                        32779
#define ID_ZOOMLEVEL                    32781
#define ID_PAGE_FIRST                   32782
#define ID_PAGE_PREV                    32783
#define ID_PAGE_NEXT                    32784
#define ID_PAGE_LAST                    32785
#define ID_RES                         32786

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_3D_CONTROLS                     1
#define _APS_NEXT_RESOURCE_VALUE        135
#define _APS_NEXT_COMMAND_VALUE         32787
#define _APS_NEXT_CONTROL_VALUE         1005
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
