#include "stdafx.h"
#include "GraphicSuite.h"

#include <math.h>

#include "MainFrm.h"
#include "GraphicSuiteDoc.h"
#include "GraphicSuiteView.h"

#include "DlgTile.h"
#include "DlgQuantize.h"
#include "DlgImageInfos.h"
#include "DlgZoom.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

extern DWORD GetFormattedLastError(CString &str);
//////////////////////////////////////////////////////////////////////
//
// CGraphicSuiteView
//
//////////////////////////////////////////////////////////////////////

IMPLEMENT_DYNCREATE(CGraphicSuiteView, CScrollView)

BEGIN_MESSAGE_MAP(CGraphicSuiteView, CScrollView)
	//{{AFX_MSG_MAP(CGraphicSuiteView)
	ON_COMMAND(ID_ZOOM_IN, OnZoomIn)
	ON_COMMAND(ID_ZOOM_OUT, OnZoomOut)
	ON_COMMAND(ID_TILE, OnTile)
	ON_COMMAND(ID_COLORS_1bit, OnColors1bit)
	ON_COMMAND(ID_COLORS_24bit, OnCOLORS24bit)
	ON_UPDATE_COMMAND_UI(ID_COLORS_24bit, OnUpdateCOLORS24bit)
	ON_COMMAND(ID_COLORS_256, OnColors256)
	ON_UPDATE_COMMAND_UI(ID_COLORS_256, OnUpdateColors256)
	ON_COMMAND(ID_COLORS_32bit, OnCOLORS32bit)
	ON_UPDATE_COMMAND_UI(ID_COLORS_32bit, OnUpdateCOLORS32bit)
	ON_UPDATE_COMMAND_UI(ID_COLORS_1bit, OnUpdateCOLORS1bit)
	ON_COMMAND(ID_INFOS, OnInfos)
	ON_UPDATE_COMMAND_UI(ID_INFOS, OnUpdateInfos)
	ON_COMMAND(ID_ZOOMLEVEL, OnZoomLevel)
	ON_UPDATE_COMMAND_UI(ID_ZOOMLEVEL, OnUpdateZoomLevel)
	ON_WM_QUERYNEWPALETTE()
	ON_WM_PALETTECHANGED()
	ON_COMMAND(ID_PAGE_FIRST, OnPageFirst)
	ON_COMMAND(ID_PAGE_LAST, OnPageLast)
	ON_COMMAND(ID_PAGE_NEXT, OnPageNext)
	ON_COMMAND(ID_PAGE_PREV, OnPagePrev)
	ON_UPDATE_COMMAND_UI(ID_PAGE_FIRST, OnUpdatePageFirst)
	ON_UPDATE_COMMAND_UI(ID_PAGE_LAST, OnUpdatePageLast)
	ON_UPDATE_COMMAND_UI(ID_PAGE_NEXT, OnUpdatePageNext)
	ON_UPDATE_COMMAND_UI(ID_PAGE_PREV, OnUpdatePagePrev)
    ON_WM_MOUSEWHEEL()
	ON_MESSAGE(WM_PAGE_OPENED, OnPageOpened)
	ON_COMMAND(ID_EDIT_COPY, OnEditCopy)
	ON_UPDATE_COMMAND_UI(ID_EDIT_COPY, OnUpdateEditCopy)
	//}}AFX_MSG_MAP
	ON_COMMAND(ID_FILE_PRINT, CScrollView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_DIRECT, CScrollView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_PREVIEW, CScrollView::OnFilePrintPreview)
END_MESSAGE_MAP()

CGraphicSuiteView::CGraphicSuiteView()
{
	m_pPalette = NULL;

	Initialize();
}

CGraphicSuiteView::~CGraphicSuiteView()
{
	if( m_pPalette )
		delete m_pPalette;
}

void CGraphicSuiteView::Initialize(void)
{
	m_Zoom			= 1.0;
	m_tiledHoriz	= 1;
	m_tiledVert		= 1;
	m_ZoomFactor	= 1.1;

	if( m_pPalette )
		delete m_pPalette;

	m_bPalCreated	= FALSE;
	m_pPalette		= NULL;
}


#define _RINT_C(i_db,o_it) \
				{double diff; \
				(o_it) = (int)(i_db);\
				diff = (i_db) - (double)(o_it); \
				if (diff >= (double)0.5) (o_it)++; \
				else if (diff <= (double)(-0.5)) (o_it)--;}

void CGraphicSuiteView::SetZoom(double value)
{
	int		erg;

	value *= 100000.0;
	_RINT_C(value, erg);
	m_Zoom = ((double)erg) / 100000.0;
	RebuildScrollSizes();
}

void CGraphicSuiteView::OnInitialUpdate() 
{
	CGraphicSuiteDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);

	CScrollView::OnInitialUpdate();
	RebuildScrollSizes();
}

void CGraphicSuiteView::RebuildScrollSizes()
{
	CSize	sizeTotal(100, 100),
			sizePage(25, 25),
			sizeLine(1, 1);

	CGraphicSuiteDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);
	
	FIBITMAP *pFIBitmap = (pDoc ? pDoc->GetFIBitmap() : NULL);

	if( pFIBitmap )
	{
		double		dpiX   = FreeImage_GetDotsPerMeterX(pFIBitmap),
					dpiY   = FreeImage_GetDotsPerMeterY(pFIBitmap),
					width  = FreeImage_GetWidth(pFIBitmap),
					height = FreeImage_GetHeight(pFIBitmap),
					sizeX,	// 1/100 mm == HIMETRIC
					sizeY;

		if( dpiX==0.0 )	dpiX = 72.0 * 100.0 / 2.54;
		if( dpiY==0.0 )	dpiY = 72.0 * 100.0 / 2.54;
		sizeX = 100.0 * 1000.0 * width  / dpiX;
		sizeY = 100.0 * 1000.0 * height / dpiY;

		sizeTotal.cx = (int) (m_tiledHoriz * sizeX * m_Zoom /*+ 0.5*/);
		sizeTotal.cy = (int) (m_tiledVert  * sizeY * m_Zoom /*+ 0.5*/);

		sizeX = sizeTotal.cx / 4.0;
		sizeY = sizeTotal.cy / 4.0;
		sizePage.cx = (long) (sizeX/*+0.5*/);
		sizePage.cy = (long) (sizeY/*+0.5*/);

		sizeX = sizeTotal.cx / 20.0;
		sizeY = sizeTotal.cy / 20.0;
		sizeLine.cx = (long) (sizeX/*+0.5*/);
		sizeLine.cy = (long) (sizeY/*+0.5*/);
	}
	
	SetScrollSizes(MM_HIMETRIC, sizeTotal, sizePage, sizeLine);
	Invalidate();
}

void TraceRect(const char *szString, CRect &rect)
{
	TRACE("%s:  l/r=(%6d %6d), o/u=(%6d %6d)\n", 
						szString,
						rect.left, rect.right,
						rect.top, rect.bottom);
}

BOOL IntersectRect(CRect &rectErg, CRect &rect1, CRect &rect2)
{
	rectErg.SetRectEmpty();

	LONG	lower,
			higher;

	if( rect1.left < rect2.left )		lower   = rect2.left;
	else								lower   = rect1.left;
	if( rect1.right < rect2.right)		higher  = rect1.right;
	else								higher  = rect2.right;

	rectErg.left  = lower;
	rectErg.right = higher;

	if( rect1.top < rect2.top )			lower   = rect1.top;
	else								lower   = rect2.top;
	if( rect1.bottom < rect2.bottom)	higher  = rect2.bottom;
	else								higher  = rect1.bottom;

	rectErg.top   = lower;
	rectErg.bottom= higher;

	return (rectErg.left<=rectErg.right) && (rectErg.bottom<=rectErg.top);
}

void CGraphicSuiteView::OnDraw(CDC* pDC)
{
	CGraphicSuiteDoc	*pDoc = GetDocument();
	CPalette			*pOldPalette = NULL;
	FIBITMAP			*pFIBitmap = (pDoc ? pDoc->GetFIBitmap() : NULL);
	
	if( !pFIBitmap )
		return;

	CRect	clipRect;
	int		erg;

	erg = pDC->GetClipBox(&clipRect);

	if( erg==ERROR || erg==NULLREGION)
		return;

	pDC->SetMapMode(MM_HIMETRIC);

	CreateMyPalette();

	if( m_pPalette!=NULL )
		pOldPalette = pDC->SelectPalette(m_pPalette, TRUE);

	::SetStretchBltMode(pDC->m_hDC, COLORONCOLOR);

	double		dpiX   = FreeImage_GetDotsPerMeterX(pFIBitmap),
				dpiY   = FreeImage_GetDotsPerMeterY(pFIBitmap),
				width  = FreeImage_GetWidth(pFIBitmap),
				height = FreeImage_GetHeight(pFIBitmap),
				sizeX,	// 1/100 mm == HIMETRIC
				sizeY;
	BYTE		*pData	= FreeImage_GetBits(pFIBitmap);
	BOOL		bInsideClip;

	// Resolution od screen or printer
	// screen: 72 or 96
	if( dpiX==0.0 )	dpiX = 100.0 / 2.54 * (double)GetDeviceCaps(pDC->m_hDC, LOGPIXELSX);
	if( dpiY==0.0 )	dpiY = 100.0 / 2.54 * (double)GetDeviceCaps(pDC->m_hDC, LOGPIXELSY);

	sizeX = m_Zoom * 100.0 * 1000.0 * width  / dpiX;
	sizeY = m_Zoom * 100.0 * 1000.0 * height / dpiY;

	int			xDst,
				yDst,
				dxDst,
				dyDst,
				xSrc,
				ySrc,
				dxSrc,
				dySrc;
	double		factorBegin,
				factorSize,
				fTemp;
	CRect		rectPicture,
				rectIntersect;

	//TraceRect("\nclipRect     ", clipRect);

	for( int i=0 ; i< m_tiledHoriz ; i++ )
	{
		for( int j=0 ; j< m_tiledVert ; j++ )
		{
			// lets see if we can see this within the clipping area
			// if not, nothing to do!
			rectPicture.left	=   i    * sizeX;
			rectPicture.right	=  (i+1) * sizeX;
			rectPicture.top		= - j    * sizeY;
			rectPicture.bottom	= -(j+1) * sizeY;
			//TraceRect("rectPicture  ", rectPicture);

			bInsideClip = ::IntersectRect(rectIntersect, clipRect, rectPicture);
			//TraceRect("rectIntersect", rectIntersect);
		
			if( !bInsideClip )
				continue;

			//
			// dst: Metric coordinates in the view
			//

			xDst = rectIntersect.left;
			yDst = rectIntersect.top;

			dxDst = rectIntersect.right  - rectIntersect.left;
			dyDst = rectIntersect.bottom - rectIntersect.top;
			
			//
			// src: pixel  coordinates from the raster
			//

			// x-dim
			factorBegin = ((double)  xDst) / ((double) sizeX);
			factorSize  = ((double) dxDst) / ((double) sizeX);
			// now calc the corresponding pixels
			fTemp = factorBegin * width;
			xSrc  = fTemp;// + 0.5;
			xSrc %= (LONG) width;

			fTemp = factorSize * width;
			dxSrc = fTemp;// + 0.5;
			
			// y-dim
			rectIntersect.top    += j * sizeY;
			rectIntersect.bottom += j * sizeY;
			fTemp = rectIntersect.bottom;
			factorBegin = 1.0 - ((double) -fTemp) / ((double)sizeY);
			factorSize  =       ((double) -dyDst) / ((double)sizeY);
			// now calc the corresponding pixels
			fTemp = factorBegin * height;
			ySrc  = fTemp;// + 0.5;
			ySrc %= (LONG) height;

			fTemp = factorSize * height;
			dySrc = fTemp;// + 0.5;

			//TRACE("m_Zoom = %f\n", m_Zoom);
			if( fabs(m_Zoom-1.0) <= 0.00002 )
			{
				// no stretching
				::SetDIBitsToDevice(
								pDC->m_hDC,		// handle to DC
								xDst,	yDst,	// x-y-coord of destination upper-left corner
								dxSrc,	dySrc,	// width-height of source rectangle
								xSrc,	ySrc,	// x-y-coord of source upper-left corner
								0,//uStartScan,// first scan line in array
								FreeImage_GetHeight(pFIBitmap),	// number of scan lines
								FreeImage_GetBits(pFIBitmap),	// array of DIB bits
								FreeImage_GetInfo(pFIBitmap),	// bitmap information
								DIB_RGB_COLORS);				// RGB or palette indexes
			}
			else
			{
				// do stretching
				::StretchDIBits(pDC->m_hDC,
							xDst,	yDst,	// x-y-coord of destination upper-left corner
							dxDst,	dyDst,	// width-height of destination rectangle
							xSrc,	ySrc,	// x-y-coord of source upper-left corner
							dxSrc,	dySrc,	// width-height of source rectangle
							pData,			// bitmap bits
							FreeImage_GetInfo(pFIBitmap),// bitmap data
							DIB_RGB_COLORS,	// usage options
							SRCCOPY);		// raster operation code
			}
		}
	}

	if( m_pPalette && pOldPalette )
		pDC->SelectPalette(pOldPalette, TRUE);
}

BOOL CGraphicSuiteView::OnPreparePrinting(CPrintInfo* pInfo)
{
	return DoPreparePrinting(pInfo);
}

void CGraphicSuiteView::OnBeginPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
}

void CGraphicSuiteView::OnEndPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
}

CGraphicSuiteDoc* CGraphicSuiteView::GetDocument()
{
	return (CGraphicSuiteDoc*)m_pDocument;
}

void CGraphicSuiteView::OnActivateView(BOOL bActivate, CView* pActivateView, CView* pDeactiveView)
{
	CScrollView::OnActivateView(bActivate, pActivateView, pDeactiveView);

	if (bActivate)
		DoRealizePalette(FALSE);
}

/////////////////////////////////////////////////////////////////////////////
//
// Palette
//
/////////////////////////////////////////////////////////////////////////////
BOOL CGraphicSuiteView::OnQueryNewPalette() 
{
	return DoRealizePalette(FALSE);
}

void CGraphicSuiteView::OnPaletteChanged(CWnd* pFocusWnd) 
{
	if (pFocusWnd != this)
		DoRealizePalette(TRUE);
}

void CGraphicSuiteView::CreateMyPalette()
{
	CGraphicSuiteDoc	*pDoc = GetDocument();
	FIBITMAP			*pFIBitmap = (pDoc ? pDoc->GetFIBitmap() : NULL);
	
	if( !pFIBitmap )
		return;

	if( !m_bPalCreated)
			return;
	else	m_bPalCreated = TRUE;
	
	RGBQUAD *pRgb = FreeImage_GetPalette(pFIBitmap);
	unsigned int count = FreeImage_GetColorsUsed(pFIBitmap);
	if( count==0 || pRgb==NULL )
		return;

	LOGPALETTE PaletteInfo;
    PaletteInfo.palNumEntries = count;
                        
    for (unsigned int i = 0; i < count; i++)
    {
        PaletteInfo.palPalEntry[i].peRed   = pRgb[i].rgbRed;
        PaletteInfo.palPalEntry[i].peGreen = pRgb[i].rgbGreen;
        PaletteInfo.palPalEntry[i].peBlue  = pRgb[i].rgbBlue;
        PaletteInfo.palPalEntry[i].peFlags = 0;
    }

    // Create Palette!
	m_pPalette = new CPalette();
    m_pPalette->CreatePalette(&PaletteInfo);
}

int CGraphicSuiteView::DoRealizePalette(BOOL bForceBackground)
{
	CGraphicSuiteDoc	*pDoc = GetDocument();
	FIBITMAP			*pFIBitmap = (pDoc ? pDoc->GetFIBitmap() : NULL);

	if( pFIBitmap )
	{
		CreateMyPalette();

		if( !m_pPalette )
			return 0;

		CMainFrame* pAppFrame = (CMainFrame*) AfxGetApp()->m_pMainWnd;
		ASSERT_KINDOF(CMainFrame, pAppFrame);

		CClientDC appDC(pAppFrame);
		// All views but one should be a background palette.
		// wParam contains a handle to the active view, so the SelectPalette
		// bForceBackground flag is FALSE only if wParam == m_hWnd (this view)
		CPalette* oldPalette = appDC.SelectPalette(m_pPalette, bForceBackground);
		int nColorsChanged = 0;
		if (oldPalette != NULL)
		{
			nColorsChanged = appDC.RealizePalette();
			if (nColorsChanged > 0)
				pDoc->UpdateAllViews(NULL);
			appDC.SelectPalette(oldPalette, TRUE);
		}
		return nColorsChanged;
	}

	return 0L;
}

void CGraphicSuiteView::OnZoomIn() 
{
	SetZoom( m_Zoom * m_ZoomFactor);
}

void CGraphicSuiteView::OnZoomOut() 
{
	SetZoom( m_Zoom / m_ZoomFactor);
}

void CGraphicSuiteView::OnTile() 
{
	CDlgTile	dlg(this);
	
	dlg.m_dHor = m_tiledHoriz;
	dlg.m_dVert = m_tiledVert;

	if( dlg.DoModal() != IDOK )
		return;

	m_tiledHoriz = dlg.m_dHor;
	m_tiledVert = dlg.m_dVert;

	RebuildScrollSizes();
}

void CGraphicSuiteView::OnColors(unsigned colors, int param)
{
	CWaitCursor	wait;
	CGraphicSuiteDoc	*pDoc = GetDocument();
	FIBITMAP			*pFIBitmap = (pDoc ? pDoc->GetFIBitmap() : NULL);

	if( !pFIBitmap )
		return;

	// has already this color-model
	if( FreeImage_GetBPP(pFIBitmap)==colors )
		return;

	FIBITMAP *pOld = pFIBitmap;
	switch(colors)
	{
		case 1:		pFIBitmap = FreeImage_ConvertTo8Bits(pOld);
					break;
		
		case 8:		pFIBitmap = FreeImage_ColorQuantize(pOld, 
															(FREE_IMAGE_QUANTIZE) param);
					break;

		case 24:	pFIBitmap = FreeImage_ConvertTo24Bits(pOld);
					break;
		
		case 32:	pFIBitmap = FreeImage_ConvertTo32Bits(pOld);
					break;
		
		default:	pFIBitmap = NULL;
					break;
	}
	
	if( pFIBitmap )
	{	
		FreeImage_Unload(pOld);
		RebuildScrollSizes();
	}
	else
	{
		pFIBitmap = pOld;
		AfxMessageBox(IDS_CONVERT_FAILED);
	}
}

void CGraphicSuiteView::OnColors1bit()	{ OnColors(1);	}
void CGraphicSuiteView::OnCOLORS24bit() { OnColors(24);	}
void CGraphicSuiteView::OnCOLORS32bit()	{ OnColors(32);	}
void CGraphicSuiteView::OnColors256() 
{
	CDlgQuantize	dlg(this);
	if( dlg.DoModal() != IDOK )
		return;
	OnColors(8, dlg.m_type);
}

void CGraphicSuiteView::OnUpdateCOLORS(CCmdUI* pCmdUI, unsigned colors)
{
	CGraphicSuiteDoc	*pDoc = GetDocument();
	FIBITMAP			*pFIBitmap = (pDoc ? pDoc->GetFIBitmap() : NULL);

	pCmdUI->Enable( pFIBitmap != NULL );
	if( pFIBitmap )
		pCmdUI->SetCheck( FreeImage_GetBPP(pFIBitmap)==colors );
}

void CGraphicSuiteView::OnUpdateCOLORS1bit(CCmdUI* pCmdUI) 
{
	OnUpdateCOLORS(pCmdUI, 1);
}

void CGraphicSuiteView::OnUpdateColors256(CCmdUI* pCmdUI) 
{
	OnUpdateCOLORS(pCmdUI, 8);
}

void CGraphicSuiteView::OnUpdateCOLORS24bit(CCmdUI* pCmdUI) 
{
	OnUpdateCOLORS(pCmdUI, 24);
}

void CGraphicSuiteView::OnUpdateCOLORS32bit(CCmdUI* pCmdUI) 
{
	OnUpdateCOLORS(pCmdUI, 32);
}

void CGraphicSuiteView::OnInfos() 
{
	CGraphicSuiteDoc	*pDoc = GetDocument();
	FIBITMAP			*pFIBitmap		= (pDoc ? pDoc->GetFIBitmap() : NULL);
	FIMULTIBITMAP		*pFIBitmapMP	= (pDoc ? pDoc->GetFIBitmapMP() : NULL);


	if( !pFIBitmap )
		return;

	CDlgImageInfos	dlg(this, pFIBitmap, pFIBitmapMP, pDoc);
	dlg.DoModal();
}

void CGraphicSuiteView::OnUpdateInfos(CCmdUI* pCmdUI) 
{
	CGraphicSuiteDoc	*pDoc = GetDocument();
	FIBITMAP			*pFIBitmap = (pDoc ? pDoc->GetFIBitmap() : NULL);

	pCmdUI->Enable( pFIBitmap != NULL );
}

void CGraphicSuiteView::OnZoomLevel() 
{
	CGraphicSuiteDoc	*pDoc = GetDocument();
	FIBITMAP			*pFIBitmap = (pDoc ? pDoc->GetFIBitmap() : NULL);

	if( !pFIBitmap )
		return;

	CDlgZoom	dlg(this, m_Zoom, m_ZoomFactor);
	if( dlg.DoModal() != IDOK )
		return;

	if( m_Zoom!=dlg.m_editValue || m_ZoomFactor!=dlg.m_editFactor )
	{
		m_ZoomFactor = dlg.m_editFactor;
		SetZoom(dlg.m_editValue);
	}
}

void CGraphicSuiteView::OnUpdateZoomLevel(CCmdUI* pCmdUI) 
{
	CGraphicSuiteDoc	*pDoc = GetDocument();
	FIBITMAP			*pFIBitmap = (pDoc ? pDoc->GetFIBitmap() : NULL);

	pCmdUI->Enable( pFIBitmap != NULL );
}


void CGraphicSuiteView::OnPageFirst() 
{
	CGraphicSuiteDoc	*pDoc		= GetDocument();
	FIBITMAP			*pFIBitmap	= (pDoc ? pDoc->GetFIBitmap() : NULL);
	int					pageCount	= (pDoc ? pDoc->GetPageCount() : 0),
						currPage	= (pDoc ? pDoc->GetCurrPage() : 0);

	if( pDoc && pDoc->SetPage(0) )
	{
		Initialize();
		Invalidate();
	}
}

void CGraphicSuiteView::OnPageLast() 
{
	CGraphicSuiteDoc	*pDoc		= GetDocument();
	FIBITMAP			*pFIBitmap	= (pDoc ? pDoc->GetFIBitmap() : NULL);
	int					pageCount	= (pDoc ? pDoc->GetPageCount() : 0),
						currPage	= (pDoc ? pDoc->GetCurrPage() : 0);

	if( pDoc && pDoc->SetPage(pageCount-1) )
	{
		Initialize();
		Invalidate();
	}
}

void CGraphicSuiteView::OnPageNext() 
{
	CGraphicSuiteDoc	*pDoc		= GetDocument();
	FIBITMAP			*pFIBitmap	= (pDoc ? pDoc->GetFIBitmap() : NULL);
	int					pageCount	= (pDoc ? pDoc->GetPageCount() : 0),
						currPage	= (pDoc ? pDoc->GetCurrPage() : 0);

	if( pDoc && pDoc->SetPage(currPage+1) )
	{
		Initialize();
		Invalidate();
	}
}

void CGraphicSuiteView::OnPagePrev() 
{
	CGraphicSuiteDoc	*pDoc		= GetDocument();
	FIBITMAP			*pFIBitmap	= (pDoc ? pDoc->GetFIBitmap() : NULL);
	int					pageCount	= (pDoc ? pDoc->GetPageCount() : 0),
						currPage	= (pDoc ? pDoc->GetCurrPage() : 0);

	if( pDoc && pDoc->SetPage(currPage-1) )
	{
		Initialize();
		Invalidate();
	}
}

void CGraphicSuiteView::OnUpdatePageFirst(CCmdUI* pCmdUI) 
{
	CGraphicSuiteDoc	*pDoc		= GetDocument();
	FIBITMAP			*pFIBitmap	= (pDoc ? pDoc->GetFIBitmap() : NULL);
	int					pageCount	= (pDoc ? pDoc->GetPageCount() : 0),
						currPage	= (pDoc ? pDoc->GetCurrPage() : 0);

	pCmdUI->Enable(pageCount>1 && currPage!=0);
}

void CGraphicSuiteView::OnUpdatePageLast(CCmdUI* pCmdUI) 
{
	CGraphicSuiteDoc	*pDoc		= GetDocument();
	FIBITMAP			*pFIBitmap	= (pDoc ? pDoc->GetFIBitmap() : NULL);
	int					pageCount	= (pDoc ? pDoc->GetPageCount() : 0),
						currPage	= (pDoc ? pDoc->GetCurrPage() : 0);

	pCmdUI->Enable(pageCount>1 && currPage!=(pageCount-1));
}

void CGraphicSuiteView::OnUpdatePageNext(CCmdUI* pCmdUI) 
{
	CGraphicSuiteDoc	*pDoc		= GetDocument();
	FIBITMAP			*pFIBitmap	= (pDoc ? pDoc->GetFIBitmap() : NULL);
	int					pageCount	= (pDoc ? pDoc->GetPageCount() : 0),
						currPage	= (pDoc ? pDoc->GetCurrPage() : 0);

	pCmdUI->Enable(pageCount>1 && currPage!=(pageCount-1));
}

void CGraphicSuiteView::OnUpdatePagePrev(CCmdUI* pCmdUI) 
{
	CGraphicSuiteDoc	*pDoc		= GetDocument();
	FIBITMAP			*pFIBitmap	= (pDoc ? pDoc->GetFIBitmap() : NULL);
	int					pageCount	= (pDoc ? pDoc->GetPageCount() : 0),
						currPage	= (pDoc ? pDoc->GetCurrPage() : 0);

	pCmdUI->Enable(pageCount>1 && currPage!=0);
}

// Handles mouse wheel notifications
// Note - if this doesn't work for win95 then use OnRegisteredMouseWheel instead
BOOL CGraphicSuiteView::OnMouseWheel(UINT nFlags, short zDelta, CPoint pt) 
{
	int amount = zDelta/WHEEL_DELTA;
	
	if( zDelta > 0 )
	{
		SetZoom(m_Zoom * (amount*m_ZoomFactor));
	}
	else if (zDelta < 0 )
	{
//		m_Zoom /= (-amount*m_ZoomFactor);
		SetZoom(-m_Zoom / (amount*m_ZoomFactor));
	}

	RebuildScrollSizes();

	return TRUE;
//	return CScrollView::OnMouseWheel(nFlags, zDelta, pt);
}

LRESULT CGraphicSuiteView::OnPageOpened(WPARAM wParam, LPARAM lParam)
{
	GET_APP(pApp)
	CGraphicSuiteDoc	*pDoc = GetDocument();

	pDoc->OnSetPage((FIBITMAP *) lParam, (int) wParam);
	Initialize();
	Invalidate();
	return 0;
}

void CGraphicSuiteView::OnEditCopy() 
{
	GET_APP(pApp)
	CGraphicSuiteDoc	*pDoc		= GetDocument();
	FIBITMAP			*pFIBitmap	= (pDoc ? pDoc->GetFIBitmap() : NULL);
	int					pageCount	= (pDoc ? pDoc->GetPageCount() : 0),
						currPage	= (pDoc ? pDoc->GetCurrPage() : 0);
	int					type		= (pFIBitmap ? FreeImage_GetColorType(pFIBitmap) : 0);

	if( !pFIBitmap )
		return;

	CWaitCursor	wait;
	try
	{
		pApp->Running(TRUE);
		if( type == FIC_MINISWHITE || type == FIC_MINISBLACK )
		{
			CWindowDC dc(NULL);
			
			CDC hdc ;
			hdc.CreateCompatibleDC(&dc);

			HBITMAP bitmap = CreateDIBitmap(hdc.GetSafeHdc(),
									FreeImage_GetInfoHeader(pFIBitmap),
									CBM_INIT,
									FreeImage_GetBits(pFIBitmap),
									FreeImage_GetInfo(pFIBitmap),
									DIB_RGB_COLORS);

			if( bitmap != NULL )
			{
				AfxGetApp()->m_pMainWnd->OpenClipboard();
				EmptyClipboard() ;
				SetClipboardData(CF_BITMAP, bitmap );
				CloseClipboard() ;
			}
		}
		else
		{
			CWindowDC dc (this);

			//----------------------
			// Create a bitmap copy:
			//----------------------
			CDC memDCDest;
			memDCDest.CreateCompatibleDC (NULL);
			
			CDC memDCSrc;
			memDCSrc.CreateCompatibleDC (NULL);
			
			HBITMAP bitmap = CreateDIBitmap(dc.GetSafeHdc(),
									FreeImage_GetInfoHeader(pFIBitmap),
									CBM_INIT,
									FreeImage_GetBits(pFIBitmap),
									FreeImage_GetInfo(pFIBitmap),
									DIB_RGB_COLORS);
			
			CBitmap *pBitmapCopy = CBitmap::FromHandle(bitmap);
			
			if( !bitmap || !pBitmapCopy )
			{
				AfxMessageBox ("Can't copy bitmap");
				pApp->Running(FALSE);
				return;
			}

	//		CBitmap* pOldBitmapDest = memDCDest.SelectObject (pBitmapCopy);
			CBitmap* pOldBitmapSrc = memDCSrc.SelectObject (pBitmapCopy);

			memDCDest.BitBlt (0, 0, FreeImage_GetWidth(pFIBitmap), 
									FreeImage_GetHeight(pFIBitmap),
									&memDCSrc, 0, 0, SRCCOPY);

	//		memDCDest.SelectObject (pOldBitmapDest);
			memDCSrc.SelectObject (pOldBitmapSrc);

			if (!OpenClipboard ())
			{
				AfxMessageBox ("Can't copy bitmap");
				pApp->Running(FALSE);
				return;
			}

			if (!::EmptyClipboard ())
			{
				AfxMessageBox ("Can't copy bitmap");
				::CloseClipboard ();
				pApp->Running(FALSE);
				return;
			}

			HANDLE hclipData = ::SetClipboardData (CF_BITMAP, pBitmapCopy->Detach ());
			if (hclipData == NULL)
			{
				AfxMessageBox ("Can't copy bitmap");
			}

			::CloseClipboard ();
		}
	}
	catch (...)
	{
		AfxMessageBox ("Can't copy bitmap");
	}
	pApp->Running(FALSE);
}

void CGraphicSuiteView::OnUpdateEditCopy(CCmdUI* pCmdUI) 
{
	CGraphicSuiteDoc	*pDoc		= GetDocument();
	FIBITMAP			*pFIBitmap	= (pDoc ? pDoc->GetFIBitmap() : NULL);

	pCmdUI->Enable(pFIBitmap!=NULL);
}

