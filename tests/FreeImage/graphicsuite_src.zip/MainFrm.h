#if !defined(AFX_MAINFRM_H__1B750DC8_582E_4379_B101_EBBBE0D07E58__INCLUDED_)
#define AFX_MAINFRM_H__1B750DC8_582E_4379_B101_EBBBE0D07E58__INCLUDED_

#pragma once

#include "AnimateBitmap.h"

class CMainFrame;

CMainFrame *GetMainFrame(BOOL bCheckIfValifWnd);

BOOL IsValidWindow(CWnd *pWnd);
BOOL IsValidWindow(CWnd &wnd);

//////////////////////////////////////////////////////////////////////
//
// CGraphicSuiteStatusBar
//
//////////////////////////////////////////////////////////////////////

class CGraphicSuiteStatusBar : public CStatusBar
{
	DECLARE_DYNAMIC(CGraphicSuiteStatusBar)

public:
	CGraphicSuiteStatusBar();
	virtual ~CGraphicSuiteStatusBar();

	void	AnimateBitmapStatusbar(UINT id, short xDim, short yDim, short animSpeed);
	BOOL	AddControlAnimation(int index);
	void	RepositionControls(void);

	CAnimateBmpCtrl	m_animate;

	//{{AFX_VIRTUAL(CGraphicSuiteStatusBar)
	//}}AFX_VIRTUAL

	//{{AFX_MSG(CGraphicSuiteStatusBar)
	afx_msg LRESULT OnSetText(WPARAM, LPARAM); 
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()


protected:

	BOOL			ChangeStatusOfAnimation(void);

	int				m_Index;	// animation
	UINT			m_Id;
	short			m_DimX,
					m_DimY,
					m_Speed;
};

//////////////////////////////////////////////////////////////////////
//
// CMainFrame
//
//////////////////////////////////////////////////////////////////////

class CMainFrame : public CMDIFrameWnd
{
	DECLARE_DYNAMIC(CMainFrame)

public:
	CMainFrame();
	virtual ~CMainFrame();

	//{{AFX_VIRTUAL(CMainFrame)
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	//}}AFX_VIRTUAL


protected:
	CGraphicSuiteStatusBar  m_wndStatusBar;
	CToolBar				m_wndToolBar;
	UINT					m_TimerIdActivated;

protected:
	//{{AFX_MSG(CMainFrame)
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
	afx_msg void OnDropFiles(HDROP hDropInfo);
	afx_msg LRESULT OnFileOpenedSingle(WPARAM wParam, LPARAM lParam);
	afx_msg LRESULT OnFileOpenedMulti(WPARAM wParam, LPARAM lParam);
	afx_msg LRESULT OnFreeImageMessage(WPARAM wParam, LPARAM lParam);
	afx_msg void OnTimer(UINT nIDEvent);
	afx_msg void OnDestroy();
	afx_msg void OnSize(UINT nType, int cx, int cy);
	//}}AFX_MSG
	afx_msg BOOL OnQueryNewPalette();
	afx_msg void OnPaletteChanged(CWnd* pFocusWnd);
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}

#endif // !defined(AFX_MAINFRM_H__1B750DC8_582E_4379_B101_EBBBE0D07E58__INCLUDED_)
