#include "stdafx.h"
#include "GraphicSuite.h"
#include "./pxshlapi/PxShlAPI.h"
#include "AFXPRIV.H"

#include "MainFrm.h"
#include "ChildFrm.h"
#include "GraphicSuiteDoc.h"
#include "GraphicSuiteView.h"
#include "DlgAbout.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

CRITICAL_SECTION	g_crtSectJobListIntern;
CRITICAL_SECTION	g_crtSectJobAdding;

BOOL	m_JobKillerIntern		= FALSE;


CGraphicSuiteApp theApp;

//////////////////////////////////////////////////////////////////////
//
// GetFormattedLastError
//
//////////////////////////////////////////////////////////////////////

DWORD GetFormattedLastError(CString &str)
{
	LPVOID	lpMessageBuffer; 
	DWORD	dwError;

	dwError = GetLastError();	/* defined in winerror.h */
	FormatMessage(	FORMAT_MESSAGE_ALLOCATE_BUFFER | FORMAT_MESSAGE_FROM_SYSTEM,
				NULL, dwError, MAKELANGID(LANG_NEUTRAL, SUBLANG_DEFAULT), /*The user default language*/
				(LPTSTR) &lpMessageBuffer, 0, NULL );

	str = (char *)lpMessageBuffer;
	LocalFree( lpMessageBuffer ); 
	return dwError;
}

//////////////////////////////////////////////////////////////////////
//
// CMultiDocTemplateGraphicSuite
//
//////////////////////////////////////////////////////////////////////

IMPLEMENT_DYNAMIC(CMultiDocTemplateGraphicSuite, CMultiDocTemplate)

CMultiDocTemplateGraphicSuite::CMultiDocTemplateGraphicSuite(UINT nIDResource, CRuntimeClass* pDocClass,
	CRuntimeClass* pFrameClass, CRuntimeClass* pViewClass)
	: CMultiDocTemplate(nIDResource, pDocClass, pFrameClass, pViewClass)
{
}

CDocument *CMultiDocTemplateGraphicSuite::OpenDocumentFileSingle(const char *lpszPathName, FIBITMAP *hBitmap)
{
	return OpenDocumentFileBoth(lpszPathName, NULL, hBitmap);
}

CDocument *CMultiDocTemplateGraphicSuite::OpenDocumentFileMulti(const char *lpszPathName, FIMULTIBITMAP *hBitmapMulti)
{
	return OpenDocumentFileBoth(lpszPathName, hBitmapMulti, NULL);
}

// see code of CMultiDocTemplate::OpenDocumentFile() in the MFC-sources !
CDocument *CMultiDocTemplateGraphicSuite::OpenDocumentFileBoth(const char *lpszPathName, FIMULTIBITMAP *hBitmapMulti, FIBITMAP *hBitmap)
{
	BOOL bMakeVisible = TRUE;
	
	CGraphicSuiteDoc* pDocument = (CGraphicSuiteDoc*) CreateNewDocument();
	if (pDocument == NULL)
	{
		TRACE0("CDocTemplate::CreateNewDocument returned NULL.\n");
		AfxMessageBox(AFX_IDP_FAILED_TO_CREATE_DOC);
		return NULL;
	}
	ASSERT_VALID(pDocument);

	BOOL bAutoDelete = pDocument->m_bAutoDelete;
	pDocument->m_bAutoDelete = FALSE;   // don't destroy if something goes wrong
	CFrameWnd* pFrame = CreateNewFrame(pDocument, NULL);
	pDocument->m_bAutoDelete = bAutoDelete;
	if (pFrame == NULL)
	{
		AfxMessageBox(AFX_IDP_FAILED_TO_CREATE_DOC);
		delete pDocument;       // explicit delete on error
		return NULL;
	}
	ASSERT_VALID(pFrame);

	if(lpszPathName == NULL && hBitmap==NULL )
	{
		// create a new document - with default document name
		SetDefaultTitle(pDocument);

		// avoid creating temporary compound file when starting up invisible
		if (!bMakeVisible)
			pDocument->m_bEmbedded = TRUE;

		if (!pDocument->OnNewDocument())
		{
			// user has be alerted to what failed in OnNewDocument
			TRACE0("CDocument::OnNewDocument returned FALSE.\n");
			pFrame->DestroyWindow();
			return NULL;
		}

		// it worked, now bump untitled count
		m_nUntitledCount++;
	}
	else
	{
		// open an existing document
		CWaitCursor wait;
		if (!pDocument->OnOpenDocument(lpszPathName, hBitmapMulti, hBitmap))
		{
			// user has be alerted to what failed in OnOpenDocument
			TRACE0("CDocument::OnOpenDocument returned FALSE.\n");
			pFrame->DestroyWindow();
			return NULL;
		}
		if( lpszPathName && *lpszPathName )
				pDocument->SetPathName(lpszPathName);
		else	SetDefaultTitle(pDocument);
	}

	InitialUpdateFrame(pFrame, pDocument, bMakeVisible);
	return pDocument;
}

//////////////////////////////////////////////////////////////////////
//
// CGraphicSuiteApp
//
//////////////////////////////////////////////////////////////////////

BEGIN_MESSAGE_MAP(CGraphicSuiteApp, CWinApp)
	//{{AFX_MSG_MAP(CGraphicSuiteApp)
	ON_COMMAND(ID_APP_ABOUT, OnAppAbout)
	ON_COMMAND(ID_FILE_OPEN, OnFileOpen)
	ON_UPDATE_COMMAND_UI(ID_EDIT_PASTE, OnUpdateEditPaste)
	ON_COMMAND(ID_EDIT_PASTE, OnEditPaste)
	ON_COMMAND(ID_RES, OnRes)
	ON_UPDATE_COMMAND_UI(ID_RES, OnUpdateRes)
	//}}AFX_MSG_MAP
	ON_COMMAND(ID_FILE_PRINT_SETUP, CWinApp::OnFilePrintSetup)
END_MESSAGE_MAP()

CGraphicSuiteApp::CGraphicSuiteApp()
{
	m_pDocTemplate	= NULL;
	m_bRunning		= FALSE;
}

void MyFreeImage_OutputMessageFunction(FREE_IMAGE_FORMAT fif, const char *msg)
{
	CMainFrame	*pFrame = ::GetMainFrame(FALSE);
	
	// coming from the background thread !!
	if( IsValidWindow(pFrame) )
		pFrame->PostMessage(WM_FREEIMAGE_MSG, (WPARAM) new CString(msg), NULL);
}

void CGraphicSuiteApp::InitJobs(BOOL bInit)
{
	if( bInit )
	{
		InitializeCriticalSection(&g_crtSectJobListIntern);

		InitializeCriticalSection(&g_crtSectJobAdding);

		m_pThreadJobListIntern		= NULL;
		m_pCurrentJobIntern			= NULL;
		m_pAddingJob			= NULL;

		StartRetrievalThreadIntern();
	}
	else
	{
		POSITION	pos;
		CJob		*pJob;
		BOOL		bErg;
		DWORD		exitCode = 0;

		StopRetrievalThreadIntern();
		// 
		// noch Jobs da => l�schen
		//
		// Intern
		EnterCriticalSection(&g_crtSectJobListIntern);
		{
			pos = m_listJobsIntern.GetHeadPosition();
			while( pos != NULL )
			{
				pJob = m_listJobsIntern.GetNext(pos);
				delete pJob;
			}
			m_listJobsIntern.RemoveAll();
		}
		LeaveCriticalSection(&g_crtSectJobListIntern);

		//
		// evtl. Thread l�schen
		//
		bErg = GetExitCodeThread(m_pThreadJobListIntern->m_hThread, &exitCode);
		if( bErg && exitCode==STILL_ACTIVE )
		{	
			TerminateThread(m_pThreadJobListIntern->m_hThread, 1);
			m_pThreadJobListIntern->Delete();
		}

		DeleteCriticalSection(&g_crtSectJobListIntern);
		DeleteCriticalSection(&g_crtSectJobAdding);
	}
}

void CGraphicSuiteApp::Running(BOOL bRunning)
{
	m_bRunning = bRunning;
}

BOOL CGraphicSuiteApp::IsRunning(void)
{
	return m_bRunning;
}

BOOL CGraphicSuiteApp::InitInstance()
{
#ifdef _AFXDLL
	Enable3dControls();
#else
	Enable3dControlsStatic();
#endif
	
	InitJobs(TRUE);

	FreeImage_SetOutputMessage(MyFreeImage_OutputMessageFunction);

	CHAR	szCurrentDir[_MAX_PATH];

	if( ::GetCurrentDirectory(_MAX_PATH, szCurrentDir) > 0 ) 
	{
		// go to exe-dir
		CString		strProgram;
		char		*ptr,
					szTemp[2*_MAX_PATH];

		::GetModuleFileName(NULL, szTemp, 2*_MAX_PATH);
		ptr = strrchr(szTemp, '\\');
		*ptr = '\0';
		::SetCurrentDirectory(szTemp);

		// load plugins
		FreeImage_DeInitialise();
		FreeImage_Initialise(FALSE); // TRUE: keine Plugins; FALSE schon Plugins
		::SetCurrentDirectory(szCurrentDir);
	}

	SetRegistryKey(_T("FreeImage"));

	LoadStdProfileSettings(16);

	m_pDocTemplate = new CMultiDocTemplateGraphicSuite(
		IDR_SUITETYPE,
		RUNTIME_CLASS(CGraphicSuiteDoc),
		RUNTIME_CLASS(CChildFrame),
		RUNTIME_CLASS(CGraphicSuiteView));
	AddDocTemplate(m_pDocTemplate);

	CMainFrame* pMainFrame = new CMainFrame;
	if (!pMainFrame->LoadFrame(IDR_MAINFRAME))
		return FALSE;
	m_pMainWnd = pMainFrame;

	CCommandLineInfo cmdInfo;
	ParseCommandLine(cmdInfo);

	if( cmdInfo.m_nShellCommand == CCommandLineInfo::FileNew )
		cmdInfo.m_nShellCommand = CCommandLineInfo::FileNothing;
	if (!ProcessShellCommand(cmdInfo))
		return FALSE;
	pMainFrame->ShowWindow(m_nCmdShow);
	pMainFrame->UpdateWindow();

	// Allow drag/drop
	m_pMainWnd->DragAcceptFiles();

	return TRUE;
}

int CGraphicSuiteApp::ExitInstance() 
{
	InitJobs(FALSE);
	return CWinApp::ExitInstance();
}

void CGraphicSuiteApp::AddRemoveMRU(const char *szLongPath, LPITEMIDLIST itemId, BOOL bOpen)
{
	int				i,
					amount = m_pRecentFileList->GetSize(),
					posFound = -1;
	CString			str;
	LPITEMIDLIST	thisItemId;

	for( i=0 ; i<amount && posFound<0 ; i++ )
	{
		str = (*m_pRecentFileList)[i];
		thisItemId = GetItemIDFromPath(str);
		if( thisItemId == itemId )
		{
			posFound = i;
			break;
		}
	}
	
	if( !bOpen && posFound>=0 )
		m_pRecentFileList->Remove(posFound );

	// it is added automatically!!
}

void CGraphicSuiteApp::OnAppAbout()
{
	CDlgAbout().DoModal();
}

void CGraphicSuiteApp::OnFileOpen() 
{
	DWORD		dwFlags =	OFN_EXPLORER | OFN_LONGNAMES | OFN_FILEMUSTEXIST |
							OFN_PATHMUSTEXIST | OFN_ALLOWMULTISELECT |OFN_HIDEREADONLY,
				MAXFILE = 2562; //2562 is the max
	CString		filter,
				file;

	filter.LoadString(IDS_STRING_FILTER_GRAPHICS);
	         
	CFileDialog	dlg(TRUE, NULL, file, dwFlags, filter, AfxGetMainWnd());
	dlg.m_ofn.nMaxFile = MAXFILE;
	char* pc = new char[MAXFILE];
	dlg.m_ofn.lpstrFile = pc;
	dlg.m_ofn.lpstrFile[0] = NULL;

	int erg = dlg.DoModal();
	if( erg != IDOK )
	{
		delete [] pc;
		return;
	}

	POSITION pos = dlg.GetStartPosition();
	while (pos != NULL)
	{
		file = dlg.GetNextPathName(pos);
		OpenDocumentFile(file);
	}

	delete [] pc;
}	

//
// Open Document by drag/drop
//

CDocument *CGraphicSuiteApp::OpenDocumentFile(LPCTSTR lpszFileName)
{
	CDocument			*pDoc = NULL;
	char				szLongPath[2*_MAX_PATH] = { 0 };
	FREE_IMAGE_FORMAT	fif;
	LPITEMIDLIST		itemId;

	// this function gets teh real long filename, nothing is cut 
	// works also for files like: "a long file.Exts"
	// if you do not do this, then a file with an extension of > 3 characters (e.g. tiff)
	// is cut and the file isn't found 
	itemId = GetItemIDFromPath(lpszFileName);
	SHGetPathFromIDList(itemId, szLongPath);

	fif = FreeImage_GetFIFFromFilename(szLongPath);
	if( !m_pDocTemplate || fif == FIF_UNKNOWN )
	{
		CString	msg;
		msg.Format(IDS_OPEN_ERROR, szLongPath);
		AfxMessageBox(msg);
		return NULL;
	}

	CJobOpenDocument *pJob = new CJobOpenDocument(AfxGetApp()->GetMainWnd(), JOB_PRIORITY_HIGH, FALSE,
			CString(szLongPath), (DWORD) itemId);
	AddJobIntern(pJob);
	
	return (CDocument*) -1;//do not remove from MRU!
}

void CGraphicSuiteApp::OnUpdateEditPaste(CCmdUI* pCmdUI) 
{
	pCmdUI->Enable(::IsClipboardFormatAvailable (CF_BITMAP));
}

FIBITMAP *CGraphicSuiteApp::OpenFromBitmap(HBITMAP hBitmap)
{
	CWaitCursor		wait;
	FIBITMAP		*dib = NULL;

	if( !hBitmap )
		return NULL;

	Running(TRUE);
	{
		BITMAP	bmp;
		CBitmap	*pBitmap;

		pBitmap = CBitmap::FromHandle(hBitmap);
		pBitmap->GetBitmap(&bmp);

		int cClrBits = (WORD)(bmp.bmPlanes * bmp.bmBitsPixel);
		CDC memDCSrc;

		memDCSrc.CreateCompatibleDC (NULL);
		dib = FreeImage_Allocate(bmp.bmWidth, bmp.bmHeight, cClrBits);

		GetDIBits(memDCSrc, hBitmap, 0, bmp.bmHeight, FreeImage_GetBits(dib),
				FreeImage_GetInfo(dib), DIB_RGB_COLORS);
	}
	Running(FALSE);

	if( !dib )
	{
		CString msg;
		GetFormattedLastError(msg);
		AfxMessageBox(msg);
		return NULL;
	}

	CMainFrame	*pFrame = ::GetMainFrame(FALSE);
	pFrame->SendMessage(WM_FILE_OPENED_SINGLE, 0, (LPARAM) dib);

	return dib;
}

void CGraphicSuiteApp::OnEditPaste() 
{
	if( !IsClipboardFormatAvailable (CF_BITMAP) )
	{
		AfxMessageBox ("Can't paste clipboard");
		return;
	}

	::OpenClipboard(NULL);
	{
		OpenFromBitmap((HBITMAP) GetClipboardData(CF_BITMAP));
	}
	::CloseClipboard();
}

void CGraphicSuiteApp::OnRes() 
{
	CBitmap		bmpFromRessource;

	// Load the bitmap resource
	bmpFromRessource.LoadBitmap(IDB_BITMAP_TEST);

	HBITMAP		hBitmap	= (HBITMAP) bmpFromRessource;
	
	OpenFromBitmap(hBitmap);
}

void CGraphicSuiteApp::OnUpdateRes(CCmdUI* pCmdUI) 
{
}
