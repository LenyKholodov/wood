#if !defined(AFX_GRAPHICSUITEDOC_H__76E74716_AEF9_4621_96A8_730E16F8682B__INCLUDED_)
#define AFX_GRAPHICSUITEDOC_H__76E74716_AEF9_4621_96A8_730E16F8682B__INCLUDED_

#pragma once

//////////////////////////////////////////////////////////////////////
//
// CGraphicSuiteDoc
//
//////////////////////////////////////////////////////////////////////
class CGraphicSuiteView;

class CGraphicSuiteDoc : public CDocument
{
	DECLARE_DYNCREATE(CGraphicSuiteDoc)

public:
	CGraphicSuiteDoc();
	virtual ~CGraphicSuiteDoc();

	BOOL			OnOpenDocument(LPCTSTR lpszPathName, FIMULTIBITMAP *hBitmapMulti, FIBITMAP *hBitmap);
	FIBITMAP		*GetFIBitmap(void);
	FIMULTIBITMAP	*GetFIBitmapMP(void);
	int				GetPageCount();
	int				GetCurrPage();
	BOOL			SetPage(int page);
	void			OnSetPage(FIBITMAP *pHandle, int page);

protected:
	
	CGraphicSuiteView *GetFirstView();

	FIBITMAP		*m_handleFI;
	FIMULTIBITMAP	*m_handleFI_MP;
	int				m_pageCount,
					m_currPage;
	CMapPtrToPtr	m_mapHandles;			

	//{{AFX_VIRTUAL(CGraphicSuiteDoc)
	public:
	virtual BOOL OnNewDocument();
	virtual void Serialize(CArchive& ar);
	virtual void DeleteContents();
	//}}AFX_VIRTUAL

protected:
	//{{AFX_MSG(CGraphicSuiteDoc)
	afx_msg void OnFileSaveAs();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};


//{{AFX_INSERT_LOCATION}}

#endif // !defined(AFX_GRAPHICSUITEDOC_H__76E74716_AEF9_4621_96A8_730E16F8682B__INCLUDED_)
