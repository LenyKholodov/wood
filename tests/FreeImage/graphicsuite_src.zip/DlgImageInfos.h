#if !defined(AFX_DLGIMAGEINFOS_H__83365291_D9ED_4040_9A98_BCB9A624F59E__INCLUDED_)
#define AFX_DLGIMAGEINFOS_H__83365291_D9ED_4040_9A98_BCB9A624F59E__INCLUDED_

#pragma once

//////////////////////////////////////////////////////////////////////
//
// CDlgImageInfos
//
//////////////////////////////////////////////////////////////////////
struct FIBITMAP;

class CDlgImageInfos : public CDialog
{
public:
	CDlgImageInfos(CWnd* pParent = NULL, FIBITMAP *pBitmap=NULL, FIMULTIBITMAP *pMP = NULL,  CDocument *pDoc=NULL);

	//{{AFX_DATA(CDlgImageInfos)
	enum { IDD = IDD_DIALOG_INFOS };
	//}}AFX_DATA

	FIBITMAP		*m_pBitmap;
	FIMULTIBITMAP	*m_pBitmapMP;
	CDocument		*m_pDoc;

	//{{AFX_VIRTUAL(CDlgImageInfos)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);
	//}}AFX_VIRTUAL

	//{{AFX_MSG(CDlgImageInfos)
	virtual BOOL OnInitDialog();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}

#endif // AFX_DLGIMAGEINFOS_H__83365291_D9ED_4040_9A98_BCB9A624F59E__INCLUDED_
