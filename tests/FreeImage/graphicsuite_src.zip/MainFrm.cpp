#include "stdafx.h"
#include "GraphicSuite.h"
#include "io.h"
#include "./pxshlapi/PxShlAPI.h"

#include "MainFrm.h"
#include "GraphicSuiteDoc.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

static CMainFrame	*wnd__FRAME				= NULL;

BOOL FileExists(const char *szFileOrDirexctory)
{
	return ( szFileOrDirexctory ? (_access(szFileOrDirexctory, 00)==0) : FALSE );
}

CMainFrame *GetMainFrame(BOOL bCheckIfValifWnd)
{
	if( !wnd__FRAME )	return NULL;
	
	if( bCheckIfValifWnd )
	{
		if( !IsValidWindow(wnd__FRAME) )
			return NULL;
	}

	return wnd__FRAME;
}

BOOL IsValidWindow(CWnd *pWnd)
{
	if( !pWnd )			return FALSE;
	if( !pWnd->m_hWnd )	return FALSE;
	return ::IsWindow(pWnd->m_hWnd);
}

BOOL IsValidWindow(CWnd &wnd)
{
	if( !wnd.m_hWnd )	return FALSE;
	return ::IsWindow(wnd.m_hWnd);
}

//////////////////////////////////////////////////////////////////////
//
// CGraphicSuiteStatusBar
//
//////////////////////////////////////////////////////////////////////

BEGIN_MESSAGE_MAP(CGraphicSuiteStatusBar, CStatusBar)
	//{{AFX_MSG_MAP(CGraphicSuiteStatusBar)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

IMPLEMENT_DYNAMIC(CGraphicSuiteStatusBar, CStatusBar)


CGraphicSuiteStatusBar::CGraphicSuiteStatusBar()
{
	m_Index				= -1;
	m_DimX				= 0;
	m_DimY				= 0;
	m_Speed				= 0;
	m_Id				= 0;
}

CGraphicSuiteStatusBar::~CGraphicSuiteStatusBar()
{
}
    
BOOL CGraphicSuiteStatusBar::AddControlAnimation(int index)
{
	m_Index = index;
	ChangeStatusOfAnimation();
	return TRUE;
}

void CGraphicSuiteStatusBar::AnimateBitmapStatusbar(UINT id, short xDim, short yDim, short animSpeed)
{
	if( IsValidWindow(m_animate) &&
		(id==m_Id) && 
		(m_DimX==xDim) &&
		(m_DimY==yDim) &&
		(m_Speed==animSpeed) )
	{
		// da braucht nix gemacht werden, da keine �nderungen in Sicht
		return;
	}
	
	m_Id		= id;
	m_DimX		= xDim;
	m_DimY		= yDim;
	m_Speed		= animSpeed;

	ChangeStatusOfAnimation();
}

BOOL CGraphicSuiteStatusBar::ChangeStatusOfAnimation(void)
{
	CRect	rect;
	int		cxWidth;
	UINT	nID,
			nStyle;

	if( !IsValidWindow(this) )
		return TRUE;

	if( m_Index<0 )
		return TRUE;

	//
	// alte Animation l�schen
	//
	if( IsValidWindow(m_animate) )
	{
		m_animate.Stop(TRUE);
		m_animate.DestroyWindow();
	}

	GetPaneInfo(m_Index, nID, nStyle, cxWidth);
	SetPaneInfo(m_Index, nID, SBPS_NOBORDERS, m_DimX);

	//
	// ggf. neue setzen
	//
	if( m_Id>0 && m_DimX!=0 && m_DimY!=0 )
	{
		GetItemRect(m_Index, &rect);
	
		if( !m_animate.Create(NULL, WS_VISIBLE|WS_CHILD, rect, this, ID_INDICATOR_ANIMATION) )
			return FALSE;

		if( !m_animate.Load(m_Id, m_DimX, m_DimY) )
			return FALSE;
		
		if( m_Speed != 0 )
			m_animate.Animate(-1, abs(m_Speed), (m_Speed>0) );
	}

	return TRUE;
}

void CGraphicSuiteStatusBar::RepositionControls(void)
{
	CRect	rect;

	if( m_Index>=0 && IsValidWindow(m_animate) )
	{
		GetItemRect(m_Index, &rect);
		m_animate.SetWindowPos(NULL, rect.left, rect.top, 0, 0, SWP_NOOWNERZORDER|SWP_NOZORDER|SWP_NOSIZE);
	}
}


//////////////////////////////////////////////////////////////////////
//
// CMainFrame
//
//////////////////////////////////////////////////////////////////////

IMPLEMENT_DYNAMIC(CMainFrame, CMDIFrameWnd)

BEGIN_MESSAGE_MAP(CMainFrame, CMDIFrameWnd)
	//{{AFX_MSG_MAP(CMainFrame)
	ON_WM_CREATE()
	ON_WM_DROPFILES()
	ON_MESSAGE(WM_FILE_OPENED_SINGLE, OnFileOpenedSingle)
	ON_MESSAGE(WM_FILE_OPENED_MULTI, OnFileOpenedMulti)
	ON_MESSAGE(WM_FREEIMAGE_MSG, OnFreeImageMessage)
	ON_WM_TIMER()
	ON_WM_DESTROY()
	ON_WM_SIZE()
	//}}AFX_MSG_MAP
	ON_WM_QUERYNEWPALETTE()
	ON_WM_PALETTECHANGED()
END_MESSAGE_MAP()

static UINT indicators[] =
{
	ID_SEPARATOR,
	ID_INDICATOR_ANIMATION,
	ID_INDICATOR_CAPS,
	ID_INDICATOR_NUM,
	ID_INDICATOR_SCRL,
};

CMainFrame::CMainFrame()
{
	wnd__FRAME			= this;
	m_TimerIdActivated	= 1;
}

CMainFrame::~CMainFrame()
{
	wnd__FRAME		= NULL;
}

int CMainFrame::OnCreate(LPCREATESTRUCT lpCreateStruct)
{
	if (CMDIFrameWnd::OnCreate(lpCreateStruct) == -1)
		return -1;
	
	if (!m_wndToolBar.CreateEx(this, TBSTYLE_FLAT, WS_CHILD | WS_VISIBLE | CBRS_TOP
		| CBRS_GRIPPER | CBRS_TOOLTIPS | CBRS_FLYBY | CBRS_SIZE_DYNAMIC) ||
		!m_wndToolBar.LoadToolBar(IDR_MAINFRAME))
	{
		TRACE0("Symbolleiste konnte nicht erstellt werden\n");
		return -1;      // Fehler bei Erstellung
	}

	if (!m_wndStatusBar.Create(this)
		|| !m_wndStatusBar.SetIndicators(indicators, sizeof(indicators)/sizeof(UINT)) 
		|| !m_wndStatusBar.AddControlAnimation(m_wndStatusBar.CommandToIndex(ID_INDICATOR_ANIMATION)) 
		)
	{
		TRACE0("Statusleiste konnte nicht erstellt werden\n");
		return -1;      // Fehler bei Erstellung
	}

	m_wndToolBar.EnableDocking(CBRS_ALIGN_ANY);
	EnableDocking(CBRS_ALIGN_ANY);
	DockControlBar(&m_wndToolBar);

	m_wndStatusBar.AnimateBitmapStatusbar(IDB_BITMAP_ANIMATE, 32, 12, 200);
	m_TimerIdActivated = SetTimer(m_TimerIdActivated, 200, NULL);

	return 0;
}

BOOL CMainFrame::PreCreateWindow(CREATESTRUCT& cs)
{
	if( !CMDIFrameWnd::PreCreateWindow(cs) )
		return FALSE;

	return TRUE;
}

BOOL CMainFrame::OnQueryNewPalette() 
{
	// always realize the palette for the active view
	CMDIChildWnd* pMDIChildWnd = MDIGetActive();
	if (pMDIChildWnd == NULL)
		return FALSE; // no active MDI child frame (no new palette)
	CView* pView = pMDIChildWnd->GetActiveView();
	ASSERT(pView != NULL);

	// just notify the target view
//	pView->SendMessage(WM_DOREALIZE, (WPARAM)pView->m_hWnd);
//	return TRUE;
	pView->SendMessage(WM_QUERYNEWPALETTE);
	return FALSE;
}

void CMainFrame::OnPaletteChanged(CWnd* pFocusWnd) 
{
	CMDIFrameWnd::OnPaletteChanged(pFocusWnd);

	// always realize the palette for the active view
	CMDIChildWnd* pMDIChildWnd = MDIGetActive();
	if (pMDIChildWnd == NULL)
		return; // no active MDI child frame
	CView* pView = pMDIChildWnd->GetActiveView();
	ASSERT(pView != NULL);

//	// notify all child windows that the palette has changed
//	SendMessageToDescendants(WM_DOREALIZE, (WPARAM)pView->m_hWnd);
	// notify all child windows that pView has changed the palette
	SendMessageToDescendants(WM_PALETTECHANGED, (WPARAM)pView->m_hWnd);
}

void CMainFrame::OnDropFiles(HDROP hDropInfo)
{
	CGraphicSuiteApp	*pApp = (CGraphicSuiteApp*) AfxGetApp();

	SetActiveWindow();      // activate us first !
	
	UINT nFiles = ::DragQueryFile(hDropInfo, (UINT)-1, NULL, 0);
	char			szLongPath[2*_MAX_PATH] = { 0 };

	for (UINT iFile = 0; iFile < nFiles; iFile++)
	{
		TCHAR szFileName[_MAX_PATH];
		::DragQueryFile(hDropInfo, iFile, szFileName, _MAX_PATH);
		
		SHGetPathFromIDList(GetItemIDFromPath(szFileName), szLongPath);
		
		pApp->OpenDocumentFile(szLongPath);		// default
	}
	::DragFinish(hDropInfo);

	CWnd::OnDropFiles(hDropInfo);
}

LRESULT CMainFrame::OnFreeImageMessage(WPARAM wParam, LPARAM lParam)
{
	CString	*pString = (CString*) wParam;
	
	if( pString )
	{
		AfxMessageBox(*pString);
		delete pString;
	}
	return 0;
}

LRESULT CMainFrame::OnFileOpenedSingle(WPARAM wParam, LPARAM lParam)
{
	GET_APP(pApp)

	char			szLongPath[2*_MAX_PATH] = { 0 };
	LPITEMIDLIST	itemFile	= (LPITEMIDLIST) wParam;
	FIBITMAP		*handleFI	= (FIBITMAP *) lParam;

	if( itemFile > 0 )
		SHGetPathFromIDList(itemFile, szLongPath);

	// handle the MRU
	if( *szLongPath )
		pApp->AddRemoveMRU(szLongPath, itemFile, handleFI!=NULL);

	if( handleFI )
	{
		pApp->m_pDocTemplate->OpenDocumentFileSingle(szLongPath, handleFI);
	}
	else
	{
		CString	msg;
		msg.Format(IDS_OPEN_ERROR, *szLongPath ? szLongPath : "-from clipboard-");
		AfxMessageBox(msg);
	}

	return 0;
}

LRESULT CMainFrame::OnFileOpenedMulti(WPARAM wParam, LPARAM lParam)
{
	GET_APP(pApp)

	char			szLongPath[2*_MAX_PATH] = { 0 };
	LPITEMIDLIST	itemFile		= (LPITEMIDLIST) wParam;
	FIMULTIBITMAP	*handleFI_MP	= (FIMULTIBITMAP *) lParam;

	SHGetPathFromIDList(itemFile, szLongPath);

	// handle the MRU
	pApp->AddRemoveMRU(szLongPath, itemFile, handleFI_MP!=NULL);

	if( handleFI_MP )
	{
		pApp->m_pDocTemplate->OpenDocumentFileMulti(szLongPath, handleFI_MP);
	}
	else
	{
		CString	msg;
		msg.Format(IDS_OPEN_ERROR, szLongPath);
		AfxMessageBox(msg);
	}

	return 0;
}

void CMainFrame::OnTimer(UINT nIDEvent) 
{
	GET_APP(pApp)

	if( nIDEvent == m_TimerIdActivated )
	{
		BOOL	bIsRunning		= m_wndStatusBar.m_animate.IsAnimating(),
				bNeedsRunning	= pApp->IsRunning();

		if( bIsRunning != bNeedsRunning )
		{
			if( bNeedsRunning )
				m_wndStatusBar.m_animate.Animate(-1, 200, TRUE);
			else
				m_wndStatusBar.m_animate.Stop(TRUE);
		}
	}
	else
		CMDIFrameWnd::OnTimer(nIDEvent);
}

void CMainFrame::OnDestroy() 
{
	KillTimer(m_TimerIdActivated);
	
	CMDIFrameWnd::OnDestroy();
}

void CMainFrame::OnSize(UINT nType, int cx, int cy) 
{
	CMDIFrameWnd::OnSize(nType, cx, cy);
	
	if( IsValidWindow(m_wndStatusBar) )
		m_wndStatusBar.RepositionControls();
}
